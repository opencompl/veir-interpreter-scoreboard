"builtin.module"() ({
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = i32, linkage = #llvm.linkage<external>, sym_name = "global", value = 0 : i32, visibility_ = 0 : i64}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %1 = "llvm.mlir.addressof"() <{global_name = @global}> : () -> !llvm.ptr
    %2 = "llvm.mlir.poison"() : () -> !llvm.ptr
    %3 = "llvm.mlir.constant"() <{value = -100 : i64}> : () -> i64
    %4 = "llvm.mlir.zero"() : () -> !llvm.ptr
    %5 = "llvm.mlir.undef"() : () -> vector<4x!llvm.ptr>
    %6 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %7 = "llvm.insertelement"(%5, %1, %6) : (vector<4x!llvm.ptr>, !llvm.ptr, i32) -> vector<4x!llvm.ptr>
    %8 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %9 = "llvm.insertelement"(%7, %1, %8) : (vector<4x!llvm.ptr>, !llvm.ptr, i32) -> vector<4x!llvm.ptr>
    %10 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %11 = "llvm.insertelement"(%9, %4, %10) : (vector<4x!llvm.ptr>, !llvm.ptr, i32) -> vector<4x!llvm.ptr>
    %12 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %13 = "llvm.insertelement"(%11, %1, %12) : (vector<4x!llvm.ptr>, !llvm.ptr, i32) -> vector<4x!llvm.ptr>
    %14 = "llvm.mlir.undef"() : () -> vector<4x!llvm.ptr>
    %15 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %16 = "llvm.insertelement"(%14, %1, %15) : (vector<4x!llvm.ptr>, !llvm.ptr, i32) -> vector<4x!llvm.ptr>
    %17 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %18 = "llvm.insertelement"(%16, %4, %17) : (vector<4x!llvm.ptr>, !llvm.ptr, i32) -> vector<4x!llvm.ptr>
    %19 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %20 = "llvm.insertelement"(%18, %4, %19) : (vector<4x!llvm.ptr>, !llvm.ptr, i32) -> vector<4x!llvm.ptr>
    %21 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %22 = "llvm.insertelement"(%20, %2, %21) : (vector<4x!llvm.ptr>, !llvm.ptr, i32) -> vector<4x!llvm.ptr>
    %23 = "llvm.alloca"(%0) <{alignment = 4 : i64, elem_type = i32}> : (i32) -> !llvm.ptr
    %24 = "llvm.icmp"(%1, %23) <{predicate = 0 : i64}> : (!llvm.ptr, !llvm.ptr) -> i1
    %25 = "llvm.icmp"(%1, %23) <{predicate = 1 : i64}> : (!llvm.ptr, !llvm.ptr) -> i1
    %26 = "llvm.icmp"(%23, %2) <{predicate = 0 : i64}> : (!llvm.ptr, !llvm.ptr) -> i1
    %27 = "llvm.icmp"(%1, %23) <{predicate = 3 : i64}> : (!llvm.ptr, !llvm.ptr) -> i1
    %28 = "llvm.getelementptr"(%1, %3) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %29 = "llvm.icmp"(%28, %1) <{predicate = 7 : i64}> : (!llvm.ptr, !llvm.ptr) -> i1
    %30 = "llvm.icmp"(%23, %1) <{predicate = 7 : i64}> : (!llvm.ptr, !llvm.ptr) -> i1
    %31 = "llvm.icmp"(%13, %22) <{predicate = 0 : i64}> : (vector<4x!llvm.ptr>, vector<4x!llvm.ptr>) -> vector<4xi1>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()