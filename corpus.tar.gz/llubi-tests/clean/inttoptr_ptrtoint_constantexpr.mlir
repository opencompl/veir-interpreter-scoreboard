"builtin.module"() ({
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = i32, linkage = #llvm.linkage<external>, sym_name = "g", value = 0 : i32, visibility_ = 0 : i64}> ({
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = i64, linkage = #llvm.linkage<external>, sym_name = "gp", visibility_ = 0 : i64}> ({
    %45 = "llvm.mlir.addressof"() <{global_name = @g}> : () -> !llvm.ptr
    %46 = "llvm.ptrtoint"(%45) : (!llvm.ptr) -> i64
    "llvm.return"(%46) : (i64) -> ()
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = i32, linkage = #llvm.linkage<external>, sym_name = "g2", value = 0 : i32, visibility_ = 0 : i64}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %1 = "llvm.mlir.constant"() <{value = 36 : i64}> : () -> i64
    %2 = "llvm.inttoptr"(%1) : (i64) -> !llvm.ptr
    %3 = "llvm.mlir.constant"() <{value = 0 : i64}> : () -> i64
    %4 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %5 = "llvm.mlir.addressof"() <{global_name = @g2}> : () -> !llvm.ptr
    %6 = "llvm.ptrtoaddr"(%5) : (!llvm.ptr) -> i64
    %7 = "llvm.mlir.constant"() <{value = 28 : i64}> : () -> i64
    %8 = "llvm.sub"(%7, %6) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %9 = "llvm.mlir.poison"() : () -> vector<2x!llvm.ptr>
    %10 = "llvm.insertelement"(%9, %5, %8) : (vector<2x!llvm.ptr>, !llvm.ptr, i64) -> vector<2x!llvm.ptr>
    %11 = "llvm.extractelement"(%10, %0) : (vector<2x!llvm.ptr>, i32) -> !llvm.ptr
    %12 = "llvm.ptrtoint"(%11) : (!llvm.ptr) -> i64
    %13 = "llvm.extractelement"(%10, %4) : (vector<2x!llvm.ptr>, i32) -> !llvm.ptr
    %14 = "llvm.ptrtoint"(%13) : (!llvm.ptr) -> i64
    %15 = "llvm.mlir.undef"() : () -> vector<2xi64>
    %16 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %17 = "llvm.insertelement"(%15, %14, %16) : (vector<2xi64>, i64, i32) -> vector<2xi64>
    %18 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %19 = "llvm.insertelement"(%17, %12, %18) : (vector<2xi64>, i64, i32) -> vector<2xi64>
    %20 = "llvm.mlir.constant"() <{value = dense<0> : vector<2xi64>}> : () -> vector<2xi64>
    %21 = "llvm.mlir.constant"() <{value = 4 : i64}> : () -> i64
    %22 = "llvm.mlir.poison"() : () -> vector<2xi64>
    %23 = "llvm.insertelement"(%22, %21, %8) : (vector<2xi64>, i64, i64) -> vector<2xi64>
    %24 = "llvm.extractelement"(%23, %0) : (vector<2xi64>, i32) -> i64
    %25 = "llvm.inttoptr"(%24) : (i64) -> !llvm.ptr
    %26 = "llvm.extractelement"(%23, %4) : (vector<2xi64>, i32) -> i64
    %27 = "llvm.inttoptr"(%26) : (i64) -> !llvm.ptr
    %28 = "llvm.mlir.undef"() : () -> vector<2x!llvm.ptr>
    %29 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %30 = "llvm.insertelement"(%28, %27, %29) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    %31 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %32 = "llvm.insertelement"(%30, %25, %31) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    %33 = "llvm.mlir.addressof"() <{global_name = @gp}> : () -> !llvm.ptr
    %34 = "llvm.alloca"(%0) <{alignment = 4 : i64, elem_type = i32}> : (i32) -> !llvm.ptr
    %35 = "llvm.alloca"(%0) <{alignment = 4 : i64, elem_type = i32}> : (i32) -> !llvm.ptr
    %36 = "llvm.ptrtoint"(%34) : (!llvm.ptr) -> i64
    %37 = "llvm.ptrtoint"(%35) : (!llvm.ptr) -> i64
    %38 = "llvm.sub"(%37, %36) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %39 = "llvm.getelementptr"(%2, %3) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    "llvm.store"(%4, %39) <{alignment = 4 : i64, ordering = 0 : i64}> : (i32, !llvm.ptr) -> ()
    %40 = "llvm.getelementptr"(%2, %38) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    "llvm.store"(%4, %40) <{alignment = 4 : i64, ordering = 0 : i64}> : (i32, !llvm.ptr) -> ()
    %41 = "llvm.add"(%19, %20) <{overflowFlags = 0 : i32}> : (vector<2xi64>, vector<2xi64>) -> vector<2xi64>
    %42 = "llvm.getelementptr"(%32, %3) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, i64) -> vector<2x!llvm.ptr>
    %43 = "llvm.load"(%33) <{alignment = 4 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> i64
    %44 = "llvm.inttoptr"(%43) : (i64) -> !llvm.ptr
    "llvm.store"(%4, %44) <{alignment = 4 : i64, ordering = 0 : i64}> : (i32, !llvm.ptr) -> ()
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()