"builtin.module"() ({
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = i32, linkage = #llvm.linkage<external>, sym_name = "value", value = 0 : i32, visibility_ = 0 : i64}> ({
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = !llvm.array<1 x ptr>, linkage = #llvm.linkage<external>, sym_name = "aggregate", visibility_ = 0 : i64}> ({
    %181 = "llvm.mlir.constant"() <{value = 1 : i64}> : () -> i64
    %182 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %183 = "llvm.getelementptr"(%182, %181) <{elem_type = i32, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %184 = "llvm.mlir.undef"() : () -> !llvm.array<1 x ptr>
    %185 = "llvm.insertvalue"(%184, %183) <{position = array<i64: 0>}> : (!llvm.array<1 x ptr>, !llvm.ptr) -> !llvm.array<1 x ptr>
    "llvm.return"(%185) : (!llvm.array<1 x ptr>) -> ()
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = i8, linkage = #llvm.linkage<external>, sym_name = "trunc", visibility_ = 0 : i64}> ({
    %178 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %179 = "llvm.ptrtoaddr"(%178) : (!llvm.ptr) -> i64
    %180 = "llvm.trunc"(%179) <{overflowFlags = 0 : i32}> : (i64) -> i8
    "llvm.return"(%180) : (i8) -> ()
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = f64, linkage = #llvm.linkage<external>, sym_name = "bitcast", visibility_ = 0 : i64}> ({
    %175 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %176 = "llvm.ptrtoaddr"(%175) : (!llvm.ptr) -> i64
    %177 = "llvm.bitcast"(%176) : (i64) -> f64
    "llvm.return"(%177) : (f64) -> ()
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = vector<2x!llvm.ptr>, linkage = #llvm.linkage<external>, sym_name = "insert", visibility_ = 0 : i64}> ({
    %169 = "llvm.mlir.constant"() <{value = 7 : i64}> : () -> i64
    %170 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %171 = "llvm.ptrtoaddr"(%170) : (!llvm.ptr) -> i64
    %172 = "llvm.sub"(%171, %169) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %173 = "llvm.mlir.zero"() : () -> vector<2x!llvm.ptr>
    %174 = "llvm.insertelement"(%173, %170, %172) : (vector<2x!llvm.ptr>, !llvm.ptr, i64) -> vector<2x!llvm.ptr>
    "llvm.return"(%174) : (vector<2x!llvm.ptr>) -> ()
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = !llvm.ptr, linkage = #llvm.linkage<external>, sym_name = "extract", visibility_ = 0 : i64}> ({
    %161 = "llvm.mlir.constant"() <{value = 1 : i64}> : () -> i64
    %162 = "llvm.mlir.constant"() <{value = 7 : i64}> : () -> i64
    %163 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %164 = "llvm.ptrtoaddr"(%163) : (!llvm.ptr) -> i64
    %165 = "llvm.sub"(%164, %162) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %166 = "llvm.mlir.zero"() : () -> vector<2x!llvm.ptr>
    %167 = "llvm.insertelement"(%166, %163, %165) : (vector<2x!llvm.ptr>, !llvm.ptr, i64) -> vector<2x!llvm.ptr>
    %168 = "llvm.extractelement"(%167, %161) : (vector<2x!llvm.ptr>, i64) -> !llvm.ptr
    "llvm.return"(%168) : (!llvm.ptr) -> ()
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = vector<2x!llvm.ptr>, linkage = #llvm.linkage<external>, sym_name = "shuffle", visibility_ = 0 : i64}> ({
    %148 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %149 = "llvm.mlir.constant"() <{value = 7 : i64}> : () -> i64
    %150 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %151 = "llvm.ptrtoaddr"(%150) : (!llvm.ptr) -> i64
    %152 = "llvm.sub"(%151, %149) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %153 = "llvm.mlir.zero"() : () -> vector<2x!llvm.ptr>
    %154 = "llvm.insertelement"(%153, %150, %152) : (vector<2x!llvm.ptr>, !llvm.ptr, i64) -> vector<2x!llvm.ptr>
    %155 = "llvm.extractelement"(%154, %148) : (vector<2x!llvm.ptr>, i32) -> !llvm.ptr
    %156 = "llvm.mlir.undef"() : () -> vector<2x!llvm.ptr>
    %157 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %158 = "llvm.insertelement"(%156, %155, %157) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    %159 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %160 = "llvm.insertelement"(%158, %155, %159) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    "llvm.return"(%160) : (vector<2x!llvm.ptr>) -> ()
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = !llvm.ptr, linkage = #llvm.linkage<external>, sym_name = "gep", visibility_ = 0 : i64}> ({
    %145 = "llvm.mlir.constant"() <{value = 1 : i64}> : () -> i64
    %146 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %147 = "llvm.getelementptr"(%146, %145) <{elem_type = i32, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    "llvm.return"(%147) : (!llvm.ptr) -> ()
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = i64, linkage = #llvm.linkage<external>, sym_name = "add", visibility_ = 0 : i64}> ({
    %141 = "llvm.mlir.constant"() <{value = 8 : i64}> : () -> i64
    %142 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %143 = "llvm.ptrtoaddr"(%142) : (!llvm.ptr) -> i64
    %144 = "llvm.add"(%143, %141) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    "llvm.return"(%144) : (i64) -> ()
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = i64, linkage = #llvm.linkage<external>, sym_name = "sub", visibility_ = 0 : i64}> ({
    %137 = "llvm.mlir.constant"() <{value = 8 : i64}> : () -> i64
    %138 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %139 = "llvm.ptrtoaddr"(%138) : (!llvm.ptr) -> i64
    %140 = "llvm.sub"(%139, %137) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    "llvm.return"(%140) : (i64) -> ()
  }) : () -> ()
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = i64, linkage = #llvm.linkage<external>, sym_name = "xor", visibility_ = 0 : i64}> ({
    %133 = "llvm.mlir.constant"() <{value = 8 : i64}> : () -> i64
    %134 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %135 = "llvm.ptrtoaddr"(%134) : (!llvm.ptr) -> i64
    %136 = "llvm.xor"(%135, %133) : (i64, i64) -> i64
    "llvm.return"(%136) : (i64) -> ()
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.addressof"() <{global_name = @aggregate}> : () -> !llvm.ptr
    %1 = "llvm.mlir.constant"() <{value = 1 : i64}> : () -> i64
    %2 = "llvm.mlir.addressof"() <{global_name = @value}> : () -> !llvm.ptr
    %3 = "llvm.getelementptr"(%2, %1) <{elem_type = i32, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %4 = "llvm.mlir.constant"() <{value = 0 : i64}> : () -> i64
    %5 = "llvm.mlir.addressof"() <{global_name = @trunc}> : () -> !llvm.ptr
    %6 = "llvm.ptrtoaddr"(%2) : (!llvm.ptr) -> i64
    %7 = "llvm.trunc"(%6) <{overflowFlags = 0 : i32}> : (i64) -> i8
    %8 = "llvm.mlir.constant"() <{value = 0 : i8}> : () -> i8
    %9 = "llvm.mlir.constant"() <{value = 9 : i64}> : () -> i64
    %10 = "llvm.sub"(%6, %9) <{overflowFlags = 2 : i32}> : (i64, i64) -> i64
    %11 = "llvm.trunc"(%10) <{overflowFlags = 0 : i32}> : (i64) -> i8
    %12 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %13 = "llvm.mlir.constant"() <{value = 7 : i64}> : () -> i64
    %14 = "llvm.sub"(%6, %13) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %15 = "llvm.mlir.poison"() : () -> vector<2xi64>
    %16 = "llvm.insertelement"(%15, %6, %14) : (vector<2xi64>, i64, i64) -> vector<2xi64>
    %17 = "llvm.extractelement"(%16, %12) : (vector<2xi64>, i32) -> i64
    %18 = "llvm.trunc"(%17) <{overflowFlags = 0 : i32}> : (i64) -> i8
    %19 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %20 = "llvm.extractelement"(%16, %19) : (vector<2xi64>, i32) -> i64
    %21 = "llvm.trunc"(%20) <{overflowFlags = 0 : i32}> : (i64) -> i8
    %22 = "llvm.mlir.undef"() : () -> vector<2xi8>
    %23 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %24 = "llvm.insertelement"(%22, %21, %23) : (vector<2xi8>, i8, i32) -> vector<2xi8>
    %25 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %26 = "llvm.insertelement"(%24, %18, %25) : (vector<2xi8>, i8, i32) -> vector<2xi8>
    %27 = "llvm.mlir.constant"() <{value = dense<0> : vector<2xi8>}> : () -> vector<2xi8>
    %28 = "llvm.mlir.addressof"() <{global_name = @bitcast}> : () -> !llvm.ptr
    %29 = "llvm.bitcast"(%6) : (i64) -> f64
    %30 = "llvm.mlir.constant"() <{value = -0.000000e+00 : f64}> : () -> f64
    %31 = "llvm.mlir.addressof"() <{global_name = @insert}> : () -> !llvm.ptr
    %32 = "llvm.mlir.zero"() : () -> vector<2x!llvm.ptr>
    %33 = "llvm.insertelement"(%32, %2, %14) : (vector<2x!llvm.ptr>, !llvm.ptr, i64) -> vector<2x!llvm.ptr>
    %34 = "llvm.insertelement"(%32, %2, %10) : (vector<2x!llvm.ptr>, !llvm.ptr, i64) -> vector<2x!llvm.ptr>
    %35 = "llvm.mlir.constant"() <{value = 6 : i64}> : () -> i64
    %36 = "llvm.sub"(%6, %35) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %37 = "llvm.insertelement"(%32, %2, %36) : (vector<2x!llvm.ptr>, !llvm.ptr, i64) -> vector<2x!llvm.ptr>
    %38 = "llvm.mlir.constant"() <{value = 8 : i64}> : () -> i64
    %39 = "llvm.sub"(%6, %38) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %40 = "llvm.mlir.zero"() : () -> vector<[2]x!llvm.ptr>
    %41 = "llvm.insertelement"(%40, %2, %39) : (vector<[2]x!llvm.ptr>, !llvm.ptr, i64) -> vector<[2]x!llvm.ptr>
    %42 = "llvm.mlir.addressof"() <{global_name = @extract}> : () -> !llvm.ptr
    %43 = "llvm.extractelement"(%33, %1) : (vector<2x!llvm.ptr>, i64) -> !llvm.ptr
    %44 = "llvm.mlir.zero"() : () -> !llvm.ptr
    %45 = "llvm.mlir.undef"() : () -> vector<2x!llvm.ptr>
    %46 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %47 = "llvm.insertelement"(%45, %44, %46) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    %48 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %49 = "llvm.insertelement"(%47, %2, %48) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    %50 = "llvm.extractelement"(%49, %10) : (vector<2x!llvm.ptr>, i64) -> !llvm.ptr
    %51 = "llvm.extractelement"(%49, %36) : (vector<2x!llvm.ptr>, i64) -> !llvm.ptr
    %52 = "llvm.extractelement"(%41, %1) : (vector<[2]x!llvm.ptr>, i64) -> !llvm.ptr
    %53 = "llvm.mlir.addressof"() <{global_name = @shuffle}> : () -> !llvm.ptr
    %54 = "llvm.extractelement"(%33, %12) : (vector<2x!llvm.ptr>, i32) -> !llvm.ptr
    %55 = "llvm.mlir.undef"() : () -> vector<2x!llvm.ptr>
    %56 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %57 = "llvm.insertelement"(%55, %54, %56) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    %58 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %59 = "llvm.insertelement"(%57, %54, %58) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    %60 = "llvm.mlir.undef"() : () -> vector<2x!llvm.ptr>
    %61 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %62 = "llvm.insertelement"(%60, %54, %61) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    %63 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %64 = "llvm.insertelement"(%62, %44, %63) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    %65 = "llvm.mlir.addressof"() <{global_name = @gep}> : () -> !llvm.ptr
    %66 = "llvm.getelementptr"(%2, %1) <{elem_type = i32, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %67 = "llvm.mlir.constant"() <{value = 2 : i64}> : () -> i64
    %68 = "llvm.getelementptr"(%2, %67) <{elem_type = i32, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %69 = "llvm.mlir.constant"() <{value = dense<[1, 2]> : vector<2xi64>}> : () -> vector<2xi64>
    %70 = "llvm.getelementptr"(%2, %69) <{elem_type = i32, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, vector<2xi64>) -> vector<2x!llvm.ptr>
    %71 = "llvm.mlir.constant"() <{value = dense<1> : vector<2xi64>}> : () -> vector<2xi64>
    %72 = "llvm.getelementptr"(%33, %71) <{elem_type = i32, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, vector<2xi64>) -> vector<2x!llvm.ptr>
    %73 = "llvm.mlir.addressof"() <{global_name = @add}> : () -> !llvm.ptr
    %74 = "llvm.add"(%6, %38) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %75 = "llvm.add"(%6, %38) <{overflowFlags = 3 : i32}> : (i64, i64) -> i64
    %76 = "llvm.mlir.constant"() <{value = 9223372036854775800 : i64}> : () -> i64
    %77 = "llvm.add"(%6, %76) <{overflowFlags = 1 : i32}> : (i64, i64) -> i64
    %78 = "llvm.mlir.constant"() <{value = -7 : i64}> : () -> i64
    %79 = "llvm.add"(%6, %78) <{overflowFlags = 2 : i32}> : (i64, i64) -> i64
    %80 = "llvm.mlir.addressof"() <{global_name = @sub}> : () -> !llvm.ptr
    %81 = "llvm.sub"(%6, %38) <{overflowFlags = 3 : i32}> : (i64, i64) -> i64
    %82 = "llvm.mlir.constant"() <{value = -9223372036854775800 : i64}> : () -> i64
    %83 = "llvm.sub"(%6, %82) <{overflowFlags = 1 : i32}> : (i64, i64) -> i64
    %84 = "llvm.mlir.addressof"() <{global_name = @xor}> : () -> !llvm.ptr
    %85 = "llvm.xor"(%6, %38) : (i64, i64) -> i64
    %86 = "llvm.xor"(%10, %1) : (i64, i64) -> i64
    %87 = "llvm.mlir.undef"() : () -> vector<2xi64>
    %88 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %89 = "llvm.insertelement"(%87, %1, %88) : (vector<2xi64>, i64, i32) -> vector<2xi64>
    %90 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %91 = "llvm.insertelement"(%89, %86, %90) : (vector<2xi64>, i64, i32) -> vector<2xi64>
    %92 = "llvm.mlir.constant"() <{value = dense<0> : vector<2xi64>}> : () -> vector<2xi64>
    %93 = "llvm.load"(%0) <{alignment = 8 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> !llvm.ptr
    %94 = "llvm.getelementptr"(%3, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %95 = "llvm.load"(%5) <{alignment = 1 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> i8
    %96 = "llvm.add"(%7, %8) <{overflowFlags = 0 : i32}> : (i8, i8) -> i8
    %97 = "llvm.add"(%11, %8) <{overflowFlags = 0 : i32}> : (i8, i8) -> i8
    %98 = "llvm.add"(%26, %27) <{overflowFlags = 0 : i32}> : (vector<2xi8>, vector<2xi8>) -> vector<2xi8>
    %99 = "llvm.load"(%28) <{alignment = 8 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> f64
    %100 = "llvm.fadd"(%29, %30) <{fastmathFlags = #llvm.fastmath<none>}> : (f64, f64) -> f64
    %101 = "llvm.load"(%31) <{alignment = 16 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> vector<2x!llvm.ptr>
    %102 = "llvm.getelementptr"(%33, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, i64) -> vector<2x!llvm.ptr>
    %103 = "llvm.getelementptr"(%34, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, i64) -> vector<2x!llvm.ptr>
    %104 = "llvm.getelementptr"(%37, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, i64) -> vector<2x!llvm.ptr>
    %105 = "llvm.getelementptr"(%41, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<[2]x!llvm.ptr>, i64) -> vector<[2]x!llvm.ptr>
    %106 = "llvm.load"(%42) <{alignment = 8 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> !llvm.ptr
    %107 = "llvm.getelementptr"(%43, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %108 = "llvm.getelementptr"(%50, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %109 = "llvm.getelementptr"(%51, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %110 = "llvm.getelementptr"(%52, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %111 = "llvm.load"(%53) <{alignment = 16 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> vector<2x!llvm.ptr>
    %112 = "llvm.getelementptr"(%59, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, i64) -> vector<2x!llvm.ptr>
    %113 = "llvm.getelementptr"(%64, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, i64) -> vector<2x!llvm.ptr>
    %114 = "llvm.load"(%65) <{alignment = 8 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> !llvm.ptr
    %115 = "llvm.getelementptr"(%3, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %116 = "llvm.getelementptr"(%66, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %117 = "llvm.getelementptr"(%68, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %118 = "llvm.getelementptr"(%70, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, i64) -> vector<2x!llvm.ptr>
    %119 = "llvm.getelementptr"(%72, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, i64) -> vector<2x!llvm.ptr>
    %120 = "llvm.load"(%73) <{alignment = 4 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> i64
    %121 = "llvm.add"(%74, %4) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %122 = "llvm.add"(%75, %4) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %123 = "llvm.add"(%77, %4) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %124 = "llvm.add"(%79, %4) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %125 = "llvm.load"(%80) <{alignment = 4 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> i64
    %126 = "llvm.add"(%39, %4) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %127 = "llvm.add"(%81, %4) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %128 = "llvm.add"(%83, %4) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %129 = "llvm.add"(%10, %4) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %130 = "llvm.load"(%84) <{alignment = 4 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> i64
    %131 = "llvm.add"(%85, %4) <{overflowFlags = 0 : i32}> : (i64, i64) -> i64
    %132 = "llvm.add"(%91, %92) <{overflowFlags = 0 : i32}> : (vector<2xi64>, vector<2xi64>) -> vector<2xi64>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()