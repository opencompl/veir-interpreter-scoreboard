"builtin.module"() ({
  "llvm.mlir.global"() <{addr_space = 0 : i32, global_type = i32, linkage = #llvm.linkage<external>, sym_name = "g", visibility_ = 0 : i64}> ({
    %28 = "llvm.mlir.undef"() : () -> i32
    "llvm.return"(%28) : (i32) -> ()
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %1 = "llvm.mlir.undef"() : () -> i32
    %2 = "llvm.mlir.addressof"() <{global_name = @g}> : () -> !llvm.ptr
    %3 = "llvm.mlir.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %4 = "llvm.mlir.undef"() : () -> f32
    %5 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %6 = "llvm.mlir.constant"() <{value = dense<0> : vector<4xi32>}> : () -> vector<4xi32>
    %7 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %8 = "llvm.mlir.constant"() <{value = false}> : () -> i1
    %9 = "llvm.mlir.constant"() <{value = 0 : i8}> : () -> i8
    %10 = "llvm.mlir.constant"() <{value = dense<0> : vector<2xi8>}> : () -> vector<2xi8>
    %11 = "llvm.mlir.zero"() : () -> !llvm.struct<(i32, vector<2xi8>)>
    %12 = "llvm.mlir.zero"() : () -> !llvm.array<4 x struct<(i32, vector<2xi8>)>>
    %13 = "llvm.mlir.undef"() : () -> !llvm.array<4 x struct<(i32, vector<2xi8>)>>
    %14 = "llvm.mlir.undef"() : () -> !llvm.ptr
    %15 = "llvm.mlir.constant"() <{value = 0 : i64}> : () -> i64
    %16 = "llvm.add"(%0, %1) <{overflowFlags = 0 : i32}> : (i32, i32) -> i32
    %17 = "llvm.add"(%0, %1) <{overflowFlags = 0 : i32}> : (i32, i32) -> i32
    %18 = "llvm.load"(%2) <{alignment = 4 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> i32
    %19 = "llvm.load"(%2) <{alignment = 4 : i64, ordering = 0 : i64}> : (!llvm.ptr) -> i32
    %20 = "llvm.fadd"(%3, %4) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %21 = "llvm.fadd"(%3, %4) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %22 = "llvm.add"(%6, %7) <{overflowFlags = 0 : i32}> : (vector<4xi32>, vector<4xi32>) -> vector<4xi32>
    %23 = "llvm.add"(%6, %7) <{overflowFlags = 0 : i32}> : (vector<4xi32>, vector<4xi32>) -> vector<4xi32>
    %24 = "llvm.select"(%8, %12, %13) <{fastmathFlags = #llvm.fastmath<none>}> : (i1, !llvm.array<4 x struct<(i32, vector<2xi8>)>>, !llvm.array<4 x struct<(i32, vector<2xi8>)>>) -> !llvm.array<4 x struct<(i32, vector<2xi8>)>>
    %25 = "llvm.select"(%8, %12, %13) <{fastmathFlags = #llvm.fastmath<none>}> : (i1, !llvm.array<4 x struct<(i32, vector<2xi8>)>>, !llvm.array<4 x struct<(i32, vector<2xi8>)>>) -> !llvm.array<4 x struct<(i32, vector<2xi8>)>>
    %26 = "llvm.getelementptr"(%14, %15) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %27 = "llvm.getelementptr"(%14, %15) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()