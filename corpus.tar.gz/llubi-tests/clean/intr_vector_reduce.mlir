"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = dense<[1, 2, 3, 4]> : vector<4xi32>}> : () -> vector<4xi32>
    %1 = "llvm.mlir.constant"() <{value = 4 : i32}> : () -> i32
    %2 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %3 = "llvm.mlir.poison"() : () -> i32
    %4 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %5 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %6 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %7 = "llvm.insertelement"(%5, %4, %6) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %8 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %9 = "llvm.insertelement"(%7, %3, %8) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %10 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %11 = "llvm.insertelement"(%9, %2, %10) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %12 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %13 = "llvm.insertelement"(%11, %1, %12) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %14 = "llvm.mlir.constant"() <{value = dense<[2, 3, 4, 5]> : vector<4xi32>}> : () -> vector<4xi32>
    %15 = "llvm.mlir.constant"() <{value = 5 : i32}> : () -> i32
    %16 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %17 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %18 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %19 = "llvm.insertelement"(%17, %16, %18) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %20 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %21 = "llvm.insertelement"(%19, %3, %20) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %22 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %23 = "llvm.insertelement"(%21, %1, %22) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %24 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %25 = "llvm.insertelement"(%23, %15, %24) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %26 = "llvm.mlir.constant"() <{value = dense<[15, 14, 13, 12]> : vector<4xi32>}> : () -> vector<4xi32>
    %27 = "llvm.mlir.constant"() <{value = 12 : i32}> : () -> i32
    %28 = "llvm.mlir.constant"() <{value = 13 : i32}> : () -> i32
    %29 = "llvm.mlir.constant"() <{value = 15 : i32}> : () -> i32
    %30 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %31 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %32 = "llvm.insertelement"(%30, %29, %31) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %33 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %34 = "llvm.insertelement"(%32, %3, %33) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %35 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %36 = "llvm.insertelement"(%34, %28, %35) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %37 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %38 = "llvm.insertelement"(%36, %27, %37) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %39 = "llvm.mlir.constant"() <{value = dense<[1, 2, 4, 8]> : vector<4xi32>}> : () -> vector<4xi32>
    %40 = "llvm.mlir.constant"() <{value = 8 : i32}> : () -> i32
    %41 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %42 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %43 = "llvm.insertelement"(%41, %4, %42) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %44 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %45 = "llvm.insertelement"(%43, %3, %44) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %46 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %47 = "llvm.insertelement"(%45, %1, %46) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %48 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %49 = "llvm.insertelement"(%47, %40, %48) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %50 = "llvm.mlir.constant"() <{value = dense<[1, 3, 7, 15]> : vector<4xi32>}> : () -> vector<4xi32>
    %51 = "llvm.mlir.constant"() <{value = 7 : i32}> : () -> i32
    %52 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %53 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %54 = "llvm.insertelement"(%52, %4, %53) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %55 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %56 = "llvm.insertelement"(%54, %3, %55) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %57 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %58 = "llvm.insertelement"(%56, %51, %57) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %59 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %60 = "llvm.insertelement"(%58, %29, %59) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %61 = "llvm.mlir.constant"() <{value = dense<[-4, -2, 7, 3]> : vector<4xi32>}> : () -> vector<4xi32>
    %62 = "llvm.mlir.constant"() <{value = -4 : i32}> : () -> i32
    %63 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %64 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %65 = "llvm.insertelement"(%63, %62, %64) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %66 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %67 = "llvm.insertelement"(%65, %3, %66) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %68 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %69 = "llvm.insertelement"(%67, %51, %68) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %70 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %71 = "llvm.insertelement"(%69, %2, %70) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %72 = "llvm.mlir.constant"() <{value = dense<[-1, 5, 9, 2]> : vector<4xi32>}> : () -> vector<4xi32>
    %73 = "llvm.mlir.constant"() <{value = 9 : i32}> : () -> i32
    %74 = "llvm.mlir.constant"() <{value = -1 : i32}> : () -> i32
    %75 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %76 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %77 = "llvm.insertelement"(%75, %74, %76) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %78 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %79 = "llvm.insertelement"(%77, %3, %78) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %80 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %81 = "llvm.insertelement"(%79, %73, %80) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %82 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %83 = "llvm.insertelement"(%81, %16, %82) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %84 = "llvm.intr.vector.reduce.add"(%0) : (vector<4xi32>) -> i32
    %85 = "llvm.intr.vector.reduce.add"(%13) : (vector<4xi32>) -> i32
    %86 = "llvm.intr.vector.reduce.mul"(%14) : (vector<4xi32>) -> i32
    %87 = "llvm.intr.vector.reduce.mul"(%25) : (vector<4xi32>) -> i32
    %88 = "llvm.intr.vector.reduce.and"(%26) : (vector<4xi32>) -> i32
    %89 = "llvm.intr.vector.reduce.and"(%38) : (vector<4xi32>) -> i32
    %90 = "llvm.intr.vector.reduce.or"(%39) : (vector<4xi32>) -> i32
    %91 = "llvm.intr.vector.reduce.or"(%49) : (vector<4xi32>) -> i32
    %92 = "llvm.intr.vector.reduce.xor"(%50) : (vector<4xi32>) -> i32
    %93 = "llvm.intr.vector.reduce.xor"(%60) : (vector<4xi32>) -> i32
    %94 = "llvm.intr.vector.reduce.smax"(%61) : (vector<4xi32>) -> i32
    %95 = "llvm.intr.vector.reduce.smax"(%71) : (vector<4xi32>) -> i32
    %96 = "llvm.intr.vector.reduce.smin"(%61) : (vector<4xi32>) -> i32
    %97 = "llvm.intr.vector.reduce.smin"(%71) : (vector<4xi32>) -> i32
    %98 = "llvm.intr.vector.reduce.umax"(%72) : (vector<4xi32>) -> i32
    %99 = "llvm.intr.vector.reduce.umax"(%83) : (vector<4xi32>) -> i32
    %100 = "llvm.intr.vector.reduce.umin"(%72) : (vector<4xi32>) -> i32
    %101 = "llvm.intr.vector.reduce.umin"(%83) : (vector<4xi32>) -> i32
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()