"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %1 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %2 = "llvm.mlir.constant"() <{value = -2147483648 : i32}> : () -> i32
    %3 = "llvm.mlir.constant"() <{value = -1 : i8}> : () -> i8
    %4 = "llvm.mlir.constant"() <{value = -128 : i8}> : () -> i8
    %5 = "llvm.mlir.constant"() <{value = 127 : i8}> : () -> i8
    %6 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %7 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %8 = "llvm.mlir.poison"() : () -> i32
    %9 = "llvm.mlir.constant"() <{value = -1 : i32}> : () -> i32
    %10 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %11 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %12 = "llvm.insertelement"(%10, %2, %11) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %13 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %14 = "llvm.insertelement"(%12, %9, %13) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %15 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %16 = "llvm.insertelement"(%14, %8, %15) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %17 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %18 = "llvm.insertelement"(%16, %7, %17) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %19 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %20 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %21 = "llvm.insertelement"(%19, %2, %20) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %22 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %23 = "llvm.insertelement"(%21, %2, %22) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %24 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %25 = "llvm.insertelement"(%23, %7, %24) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %26 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %27 = "llvm.insertelement"(%25, %8, %26) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %28 = "llvm.mlir.constant"() <{value = dense<1> : vector<4xi32>}> : () -> vector<4xi32>
    %29 = "llvm.mlir.constant"() <{value = dense<0> : vector<4xi32>}> : () -> vector<4xi32>
    %30 = "llvm.mlir.constant"() <{value = false}> : () -> i1
    %31 = "llvm.mlir.constant"() <{value = true}> : () -> i1
    %32 = "llvm.mlir.constant"() <{value = dense<[true, true, false, false]> : vector<4xi1>}> : () -> vector<4xi1>
    %33 = "llvm.mlir.constant"() <{value = dense<[true, false, true, false]> : vector<4xi1>}> : () -> vector<4xi1>
    %34 = "llvm.mlir.constant"() <{value = -3 : i32}> : () -> i32
    %35 = "llvm.mlir.constant"() <{value = -16 : i8}> : () -> i8
    %36 = "llvm.mlir.constant"() <{value = 9 : i8}> : () -> i8
    %37 = "llvm.mlir.constant"() <{value = 16 : i8}> : () -> i8
    %38 = "llvm.mlir.constant"() <{value = 90 : i32}> : () -> i32
    %39 = "llvm.mlir.constant"() <{value = 15 : i32}> : () -> i32
    %40 = "llvm.mlir.constant"() <{value = 4 : i32}> : () -> i32
    %41 = "llvm.mlir.constant"() <{value = 16 : i32}> : () -> i32
    %42 = "llvm.mlir.constant"() <{value = 65533 : i32}> : () -> i32
    %43 = "llvm.mlir.constant"() <{value = 511 : i32}> : () -> i32
    %44 = "llvm.mlir.constant"() <{value = 255 : i32}> : () -> i32
    %45 = "llvm.mlir.poison"() : () -> i8
    %46 = "llvm.mlir.constant"() <{value = 1 : i8}> : () -> i8
    %47 = "llvm.mlir.constant"() <{value = 15 : i8}> : () -> i8
    %48 = "llvm.mlir.constant"() <{value = 10 : i8}> : () -> i8
    %49 = "llvm.mlir.constant"() <{value = 13 : i8}> : () -> i8
    %50 = "llvm.mlir.constant"() <{value = 12 : i8}> : () -> i8
    %51 = "llvm.mlir.constant"() <{value = 3 : i8}> : () -> i8
    %52 = "llvm.mlir.constant"() <{value = 8 : i8}> : () -> i8
    %53 = "llvm.mlir.constant"() <{value = 32 : i8}> : () -> i8
    %54 = "llvm.mlir.constant"() <{value = 2 : i8}> : () -> i8
    %55 = "llvm.mlir.constant"() <{value = 4 : i8}> : () -> i8
    %56 = "llvm.mlir.constant"() <{value = 5 : i8}> : () -> i8
    %57 = "llvm.mlir.constant"() <{value = 126 : i8}> : () -> i8
    %58 = "llvm.mlir.constant"() <{value = 0 : i8}> : () -> i8
    %59 = "llvm.mlir.poison"() : () -> i1
    %60 = "llvm.mlir.undef"() : () -> vector<3xi1>
    %61 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %62 = "llvm.insertelement"(%60, %31, %61) : (vector<3xi1>, i1, i32) -> vector<3xi1>
    %63 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %64 = "llvm.insertelement"(%62, %30, %63) : (vector<3xi1>, i1, i32) -> vector<3xi1>
    %65 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %66 = "llvm.insertelement"(%64, %59, %65) : (vector<3xi1>, i1, i32) -> vector<3xi1>
    %67 = "llvm.mlir.constant"() <{value = dense<10> : vector<3xi32>}> : () -> vector<3xi32>
    %68 = "llvm.mlir.constant"() <{value = dense<20> : vector<3xi32>}> : () -> vector<3xi32>
    %69 = "llvm.mlir.constant"() <{value = dense<10> : vector<2xi32>}> : () -> vector<2xi32>
    %70 = "llvm.mlir.constant"() <{value = dense<20> : vector<2xi32>}> : () -> vector<2xi32>
    %71 = "llvm.mlir.constant"() <{value = 0 : i16}> : () -> i16
    %72 = "llvm.mlir.constant"() <{value = dense<0> : vector<2xi16>}> : () -> vector<2xi16>
    %73 = "llvm.mlir.zero"() : () -> !llvm.struct<(vector<2xi16>)>
    %74 = "llvm.mlir.constant"() <{value = dense<false> : tensor<2xi1>}> : () -> !llvm.array<2 x i1>
    %75 = "llvm.mlir.zero"() : () -> !llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>
    %76 = "llvm.mlir.constant"() <{value = dense<[1, 2]> : vector<2xi16>}> : () -> vector<2xi16>
    %77 = "llvm.mlir.undef"() : () -> !llvm.struct<(vector<2xi16>)>
    %78 = "llvm.insertvalue"(%77, %76) <{position = array<i64: 0>}> : (!llvm.struct<(vector<2xi16>)>, vector<2xi16>) -> !llvm.struct<(vector<2xi16>)>
    %79 = "llvm.mlir.undef"() : () -> !llvm.array<2 x i1>
    %80 = "llvm.insertvalue"(%79, %31) <{position = array<i64: 0>}> : (!llvm.array<2 x i1>, i1) -> !llvm.array<2 x i1>
    %81 = "llvm.insertvalue"(%80, %59) <{position = array<i64: 1>}> : (!llvm.array<2 x i1>, i1) -> !llvm.array<2 x i1>
    %82 = "llvm.mlir.undef"() : () -> !llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>
    %83 = "llvm.insertvalue"(%82, %7) <{position = array<i64: 0>}> : (!llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>, i32) -> !llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>
    %84 = "llvm.insertvalue"(%83, %81) <{position = array<i64: 1>}> : (!llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>, !llvm.array<2 x i1>) -> !llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>
    %85 = "llvm.insertvalue"(%84, %78) <{position = array<i64: 2>}> : (!llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>, !llvm.struct<(vector<2xi16>)>) -> !llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>
    %86 = "llvm.add"(%0, %1) <{overflowFlags = 0 : i32}> : (i32, i32) -> i32
    %87 = "llvm.add"(%2, %2) <{overflowFlags = 2 : i32}> : (i32, i32) -> i32
    %88 = "llvm.add"(%3, %4) <{overflowFlags = 1 : i32}> : (i8, i8) -> i8
    %89 = "llvm.add"(%5, %5) <{overflowFlags = 1 : i32}> : (i8, i8) -> i8
    %90 = "llvm.add"(%86, %6) <{overflowFlags = 0 : i32}> : (i32, i32) -> i32
    %91 = "llvm.add"(%87, %1) <{overflowFlags = 0 : i32}> : (i32, i32) -> i32
    %92 = "llvm.add"(%18, %27) <{overflowFlags = 3 : i32}> : (vector<4xi32>, vector<4xi32>) -> vector<4xi32>
    %93 = "llvm.add"(%28, %29) <{overflowFlags = 0 : i32}> : (vector<4xi32>, vector<4xi32>) -> vector<4xi32>
    %94 = "llvm.add"(%32, %33) <{overflowFlags = 0 : i32}> : (vector<4xi1>, vector<4xi1>) -> vector<4xi1>
    %95 = "llvm.sub"(%0, %1) <{overflowFlags = 0 : i32}> : (i32, i32) -> i32
    %96 = "llvm.sub"(%7, %0) <{overflowFlags = 2 : i32}> : (i32, i32) -> i32
    %97 = "llvm.sub"(%2, %0) <{overflowFlags = 1 : i32}> : (i32, i32) -> i32
    %98 = "llvm.sub"(%7, %2) <{overflowFlags = 1 : i32}> : (i32, i32) -> i32
    %99 = "llvm.mul"(%1, %34) <{overflowFlags = 0 : i32}> : (i32, i32) -> i32
    %100 = "llvm.mul"(%35, %36) <{overflowFlags = 1 : i32}> : (i8, i8) -> i8
    %101 = "llvm.mul"(%37, %37) <{overflowFlags = 2 : i32}> : (i8, i8) -> i8
    %102 = "llvm.sdiv"(%38, %39) : (i32, i32) -> i32
    %103 = "llvm.sdiv"(%8, %102) : (i32, i32) -> i32
    %104 = "llvm.sdiv"(%40, %1) : (i32, i32) -> i32
    %105 = "llvm.sdiv"(%6, %1) <{isExact}> : (i32, i32) -> i32
    %106 = "llvm.srem"(%38, %41) : (i32, i32) -> i32
    %107 = "llvm.srem"(%8, %0) : (i32, i32) -> i32
    %108 = "llvm.udiv"(%38, %39) : (i32, i32) -> i32
    %109 = "llvm.udiv"(%8, %108) : (i32, i32) -> i32
    %110 = "llvm.udiv"(%40, %1) : (i32, i32) -> i32
    %111 = "llvm.udiv"(%6, %1) <{isExact}> : (i32, i32) -> i32
    %112 = "llvm.urem"(%38, %41) : (i32, i32) -> i32
    %113 = "llvm.urem"(%8, %0) : (i32, i32) -> i32
    %114 = "llvm.trunc"(%42) <{overflowFlags = 0 : i32}> : (i32) -> i8
    %115 = "llvm.trunc"(%8) <{overflowFlags = 0 : i32}> : (i32) -> i8
    %116 = "llvm.trunc"(%9) <{overflowFlags = 1 : i32}> : (i32) -> i8
    %117 = "llvm.trunc"(%43) <{overflowFlags = 1 : i32}> : (i32) -> i8
    %118 = "llvm.trunc"(%44) <{overflowFlags = 2 : i32}> : (i32) -> i8
    %119 = "llvm.trunc"(%43) <{overflowFlags = 2 : i32}> : (i32) -> i8
    %120 = "llvm.zext"(%3) : (i8) -> i32
    %121 = "llvm.zext"(%45) : (i8) -> i32
    %122 = "llvm.zext"(%46) <{nonNeg}> : (i8) -> i32
    %123 = "llvm.zext"(%3) <{nonNeg}> : (i8) -> i32
    %124 = "llvm.sext"(%3) : (i8) -> i32
    %125 = "llvm.sext"(%45) : (i8) -> i32
    %126 = "llvm.and"(%47, %48) : (i8, i8) -> i8
    %127 = "llvm.xor"(%49, %48) : (i8, i8) -> i8
    %128 = "llvm.or"(%47, %48) : (i8, i8) -> i8
    %129 = "llvm.or"(%50, %51) <{isDisjoint}> : (i8, i8) -> i8
    %130 = "llvm.or"(%47, %48) <{isDisjoint}> : (i8, i8) -> i8
    %131 = "llvm.shl"(%5, %51) <{overflowFlags = 0 : i32}> : (i8, i8) -> i8
    %132 = "llvm.shl"(%5, %52) <{overflowFlags = 0 : i32}> : (i8, i8) -> i8
    %133 = "llvm.shl"(%53, %46) <{overflowFlags = 1 : i32}> : (i8, i8) -> i8
    %134 = "llvm.shl"(%53, %54) <{overflowFlags = 1 : i32}> : (i8, i8) -> i8
    %135 = "llvm.shl"(%48, %55) <{overflowFlags = 2 : i32}> : (i8, i8) -> i8
    %136 = "llvm.shl"(%48, %56) <{overflowFlags = 2 : i32}> : (i8, i8) -> i8
    %137 = "llvm.lshr"(%5, %51) : (i8, i8) -> i8
    %138 = "llvm.lshr"(%57, %46) <{isExact}> : (i8, i8) -> i8
    %139 = "llvm.lshr"(%46, %46) <{isExact}> : (i8, i8) -> i8
    %140 = "llvm.lshr"(%58, %52) <{isExact}> : (i8, i8) -> i8
    %141 = "llvm.ashr"(%5, %51) : (i8, i8) -> i8
    %142 = "llvm.ashr"(%57, %46) <{isExact}> : (i8, i8) -> i8
    %143 = "llvm.ashr"(%46, %46) <{isExact}> : (i8, i8) -> i8
    %144 = "llvm.ashr"(%58, %52) <{isExact}> : (i8, i8) -> i8
    %145 = "llvm.select"(%31, %30, %59) <{fastmathFlags = #llvm.fastmath<none>}> : (i1, i1, i1) -> i1
    %146 = "llvm.select"(%66, %67, %68) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<3xi1>, vector<3xi32>, vector<3xi32>) -> vector<3xi32>
    %147 = "llvm.select"(%30, %69, %70) <{fastmathFlags = #llvm.fastmath<none>}> : (i1, vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    %148 = "llvm.select"(%30, %75, %85) <{fastmathFlags = #llvm.fastmath<none>}> : (i1, !llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>, !llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>) -> !llvm.struct<(i32, array<2 x i1>, struct<(vector<2xi16>)>)>
    %149 = "llvm.icmp"(%0, %1) <{predicate = 0 : i64}> : (i32, i32) -> i1
    %150 = "llvm.icmp"(%8, %7) <{predicate = 0 : i64}> : (i32, i32) -> i1
    %151 = "llvm.icmp"(%0, %7) <{predicate = 6 : i64}> : (i32, i32) -> i1
    %152 = "llvm.icmp"(%0, %9) <{predicate = 6 : i64}> : (i32, i32) -> i1
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()