"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1.000000e+00 : f32}> : () -> f32
    %1 = "llvm.mlir.constant"() <{value = 2.000000e+00 : f32}> : () -> f32
    %2 = "llvm.mlir.constant"() <{value = -0.000000e+00 : f32}> : () -> f32
    %3 = "llvm.mlir.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %4 = "llvm.mlir.constant"() <{value = 0x7FC00042 : f32}> : () -> f32
    %5 = "llvm.mlir.constant"() <{value = 0x7F800042 : f32}> : () -> f32
    %6 = "llvm.mlir.poison"() : () -> f32
    %7 = "llvm.mlir.constant"() <{value = 4.000000e+00 : f32}> : () -> f32
    %8 = "llvm.mlir.undef"() : () -> vector<4xf32>
    %9 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %10 = "llvm.insertelement"(%8, %0, %9) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %11 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %12 = "llvm.insertelement"(%10, %6, %11) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %13 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %14 = "llvm.insertelement"(%12, %4, %13) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %15 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %16 = "llvm.insertelement"(%14, %7, %15) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %17 = "llvm.mlir.undef"() : () -> vector<4xf32>
    %18 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %19 = "llvm.insertelement"(%17, %1, %18) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %20 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %21 = "llvm.insertelement"(%19, %1, %20) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %22 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %23 = "llvm.insertelement"(%21, %1, %22) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %24 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %25 = "llvm.insertelement"(%23, %6, %24) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %26 = "llvm.intr.maxnum"(%0, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %27 = "llvm.intr.maxnum"(%2, %3) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %28 = "llvm.intr.maxnum"(%4, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %29 = "llvm.intr.maxnum"(%1, %4) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %30 = "llvm.intr.maxnum"(%5, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %31 = "llvm.intr.maxnum"(%1, %5) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %32 = "llvm.intr.maxnum"(%6, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %33 = "llvm.intr.maxnum"(%0, %6) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %34 = "llvm.intr.maxnum"(%16, %25) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<4xf32>, vector<4xf32>) -> vector<4xf32>
    %35 = "llvm.intr.minnum"(%0, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %36 = "llvm.intr.minnum"(%2, %3) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %37 = "llvm.intr.minnum"(%4, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %38 = "llvm.intr.minnum"(%1, %4) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %39 = "llvm.intr.minnum"(%5, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %40 = "llvm.intr.minnum"(%1, %5) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %41 = "llvm.intr.minnum"(%6, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %42 = "llvm.intr.minnum"(%0, %6) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %43 = "llvm.intr.minnum"(%16, %25) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<4xf32>, vector<4xf32>) -> vector<4xf32>
    %44 = "llvm.intr.maximum"(%0, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %45 = "llvm.intr.maximum"(%2, %3) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %46 = "llvm.intr.maximum"(%4, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %47 = "llvm.intr.maximum"(%1, %4) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %48 = "llvm.intr.maximum"(%5, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %49 = "llvm.intr.maximum"(%1, %5) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %50 = "llvm.intr.maximum"(%6, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %51 = "llvm.intr.maximum"(%0, %6) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %52 = "llvm.intr.maximum"(%16, %25) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<4xf32>, vector<4xf32>) -> vector<4xf32>
    %53 = "llvm.intr.minimum"(%0, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %54 = "llvm.intr.minimum"(%2, %3) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %55 = "llvm.intr.minimum"(%4, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %56 = "llvm.intr.minimum"(%1, %4) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %57 = "llvm.intr.minimum"(%5, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %58 = "llvm.intr.minimum"(%1, %5) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %59 = "llvm.intr.minimum"(%6, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %60 = "llvm.intr.minimum"(%0, %6) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %61 = "llvm.intr.minimum"(%16, %25) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<4xf32>, vector<4xf32>) -> vector<4xf32>
    %62 = "llvm.call_intrinsic"(%0, %1) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.maximumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %63 = "llvm.call_intrinsic"(%2, %3) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.maximumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %64 = "llvm.call_intrinsic"(%4, %1) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.maximumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %65 = "llvm.call_intrinsic"(%1, %4) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.maximumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %66 = "llvm.call_intrinsic"(%5, %1) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.maximumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %67 = "llvm.call_intrinsic"(%1, %5) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.maximumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %68 = "llvm.call_intrinsic"(%6, %1) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.maximumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %69 = "llvm.call_intrinsic"(%0, %6) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.maximumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %70 = "llvm.call_intrinsic"(%16, %25) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.maximumnum.v4f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (vector<4xf32>, vector<4xf32>) -> vector<4xf32>
    %71 = "llvm.call_intrinsic"(%0, %1) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.minimumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %72 = "llvm.call_intrinsic"(%2, %3) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.minimumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %73 = "llvm.call_intrinsic"(%4, %1) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.minimumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %74 = "llvm.call_intrinsic"(%1, %4) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.minimumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %75 = "llvm.call_intrinsic"(%5, %1) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.minimumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %76 = "llvm.call_intrinsic"(%1, %5) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.minimumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %77 = "llvm.call_intrinsic"(%6, %1) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.minimumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %78 = "llvm.call_intrinsic"(%0, %6) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.minimumnum.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (f32, f32) -> f32
    %79 = "llvm.call_intrinsic"(%16, %25) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.minimumnum.v4f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (vector<4xf32>, vector<4xf32>) -> vector<4xf32>
    "llvm.return"() : () -> ()
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<f32 (f32, f32)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nocreateundeforpoison", "nofree", "nosync", "speculatable"], sym_name = "llvm.maximumnum.f32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<vector<4xf32> (vector<4xf32>, vector<4xf32>)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nocreateundeforpoison", "nofree", "nosync", "speculatable"], sym_name = "llvm.maximumnum.v4f32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<f32 (f32, f32)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nocreateundeforpoison", "nofree", "nosync", "speculatable"], sym_name = "llvm.minimumnum.f32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<vector<4xf32> (vector<4xf32>, vector<4xf32>)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nocreateundeforpoison", "nofree", "nosync", "speculatable"], sym_name = "llvm.minimumnum.v4f32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()