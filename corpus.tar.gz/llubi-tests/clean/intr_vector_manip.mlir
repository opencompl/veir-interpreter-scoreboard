"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = dense<[0, 1, 2, 3, 4, 5]> : vector<6xi32>}> : () -> vector<6xi32>
    %1 = "llvm.mlir.constant"() <{value = dense<[10, 11]> : vector<2xi32>}> : () -> vector<2xi32>
    %2 = "llvm.mlir.constant"() <{value = 11 : i32}> : () -> i32
    %3 = "llvm.mlir.poison"() : () -> i32
    %4 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %5 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %6 = "llvm.insertelement"(%4, %3, %5) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %7 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %8 = "llvm.insertelement"(%6, %2, %7) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %9 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %10 = "llvm.mlir.constant"() <{value = dense<0> : vector<6xi32>}> : () -> vector<6xi32>
    %11 = "llvm.mlir.constant"() <{value = dense<[9, 10]> : vector<2xi32>}> : () -> vector<2xi32>
    %12 = "llvm.mlir.constant"() <{value = 5 : i32}> : () -> i32
    %13 = "llvm.mlir.constant"() <{value = 4 : i32}> : () -> i32
    %14 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %15 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %16 = "llvm.mlir.undef"() : () -> vector<6xi32>
    %17 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %18 = "llvm.insertelement"(%16, %9, %17) : (vector<6xi32>, i32, i32) -> vector<6xi32>
    %19 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %20 = "llvm.insertelement"(%18, %3, %19) : (vector<6xi32>, i32, i32) -> vector<6xi32>
    %21 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %22 = "llvm.insertelement"(%20, %15, %21) : (vector<6xi32>, i32, i32) -> vector<6xi32>
    %23 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %24 = "llvm.insertelement"(%22, %14, %23) : (vector<6xi32>, i32, i32) -> vector<6xi32>
    %25 = "llvm.mlir.constant"() <{value = 4 : i32}> : () -> i32
    %26 = "llvm.insertelement"(%24, %13, %25) : (vector<6xi32>, i32, i32) -> vector<6xi32>
    %27 = "llvm.mlir.constant"() <{value = 5 : i32}> : () -> i32
    %28 = "llvm.insertelement"(%26, %12, %27) : (vector<6xi32>, i32, i32) -> vector<6xi32>
    %29 = "llvm.mlir.constant"() <{value = dense<[0, 1, 2, 3]> : vector<4xi32>}> : () -> vector<4xi32>
    %30 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %31 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %32 = "llvm.insertelement"(%30, %9, %31) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %33 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %34 = "llvm.insertelement"(%32, %3, %33) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %35 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %36 = "llvm.insertelement"(%34, %15, %35) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %37 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %38 = "llvm.insertelement"(%36, %14, %37) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %39 = "llvm.mlir.constant"() <{value = dense<[10, 11, 12, 13]> : vector<4xi32>}> : () -> vector<4xi32>
    %40 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %41 = "llvm.mlir.constant"() <{value = dense<0> : vector<4xi32>}> : () -> vector<4xi32>
    %42 = "llvm.intr.vector.insert"(%0, %1) <{pos = 2 : i64}> : (vector<6xi32>, vector<2xi32>) -> vector<6xi32>
    %43 = "llvm.intr.vector.insert"(%0, %8) <{pos = 2 : i64}> : (vector<6xi32>, vector<2xi32>) -> vector<6xi32>
    %44 = "llvm.intr.vector.insert"(%10, %11) <{pos = 4 : i64}> : (vector<6xi32>, vector<2xi32>) -> vector<6xi32>
    %45 = "llvm.intr.vector.extract"(%0) <{pos = 2 : i64}> : (vector<6xi32>) -> vector<2xi32>
    %46 = "llvm.intr.vector.extract"(%28) <{pos = 0 : i64}> : (vector<6xi32>) -> vector<2xi32>
    %47 = "llvm.intr.vector.extract"(%0) <{pos = 4 : i64}> : (vector<6xi32>) -> vector<2xi32>
    %48 = "llvm.call_intrinsic"(%29) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.vector.reverse.v4i32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (vector<4xi32>) -> vector<4xi32>
    %49 = "llvm.call_intrinsic"(%38) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.vector.reverse.v4i32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (vector<4xi32>) -> vector<4xi32>
    %50 = "llvm.call_intrinsic"(%29, %39, %15) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.vector.splice.left.v4i32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 3, 0>}> : (vector<4xi32>, vector<4xi32>, i32) -> vector<4xi32>
    %51 = "llvm.call_intrinsic"(%38, %39, %40) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.vector.splice.left.v4i32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 3, 0>}> : (vector<4xi32>, vector<4xi32>, i32) -> vector<4xi32>
    %52 = "llvm.call_intrinsic"(%38, %39, %12) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.vector.splice.left.v4i32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 3, 0>}> : (vector<4xi32>, vector<4xi32>, i32) -> vector<4xi32>
    %53 = "llvm.call_intrinsic"(%29, %39, %40) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.vector.splice.right.v4i32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 3, 0>}> : (vector<4xi32>, vector<4xi32>, i32) -> vector<4xi32>
    %54 = "llvm.call_intrinsic"(%29, %39, %9) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.vector.splice.right.v4i32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 3, 0>}> : (vector<4xi32>, vector<4xi32>, i32) -> vector<4xi32>
    %55 = "llvm.call_intrinsic"(%29, %39, %12) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.vector.splice.right.v4i32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 3, 0>}> : (vector<4xi32>, vector<4xi32>, i32) -> vector<4xi32>
    %56 = "llvm.call_intrinsic"(%41, %41, %3) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.vector.splice.left.v4i32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 3, 0>}> : (vector<4xi32>, vector<4xi32>, i32) -> vector<4xi32>
    %57 = "llvm.call_intrinsic"(%41, %41, %3) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.vector.splice.right.v4i32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 3, 0>}> : (vector<4xi32>, vector<4xi32>, i32) -> vector<4xi32>
    "llvm.return"() : () -> ()
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<vector<4xi32> (vector<4xi32>)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nofree", "nosync", "speculatable"], sym_name = "llvm.vector.reverse.v4i32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<vector<4xi32> (vector<4xi32>, vector<4xi32>, i32)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nofree", "nosync", "speculatable"], sym_name = "llvm.vector.splice.left.v4i32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<vector<4xi32> (vector<4xi32>, vector<4xi32>, i32)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nofree", "nosync", "speculatable"], sym_name = "llvm.vector.splice.right.v4i32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()