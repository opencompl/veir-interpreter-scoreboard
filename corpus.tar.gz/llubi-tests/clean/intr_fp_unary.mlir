"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = -1.500000e+00 : f32}> : () -> f32
    %1 = "llvm.mlir.constant"() <{value = -0.000000e+00 : f32}> : () -> f32
    %2 = "llvm.mlir.poison"() : () -> f32
    %3 = "llvm.mlir.constant"() <{value = 2.000000e+00 : f32}> : () -> f32
    %4 = "llvm.mlir.constant"() <{value = -1.000000e+00 : f32}> : () -> f32
    %5 = "llvm.mlir.undef"() : () -> vector<4xf32>
    %6 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %7 = "llvm.insertelement"(%5, %4, %6) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %8 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %9 = "llvm.insertelement"(%7, %2, %8) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %10 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %11 = "llvm.insertelement"(%9, %3, %10) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %12 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %13 = "llvm.insertelement"(%11, %1, %12) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %14 = "llvm.mlir.constant"() <{value = 1.000000e+00 : f32}> : () -> f32
    %15 = "llvm.mlir.constant"() <{value = -2.000000e+00 : f32}> : () -> f32
    %16 = "llvm.mlir.constant"() <{value = 3.000000e+00 : f32}> : () -> f32
    %17 = "llvm.mlir.undef"() : () -> vector<4xf32>
    %18 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %19 = "llvm.insertelement"(%17, %14, %18) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %20 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %21 = "llvm.insertelement"(%19, %2, %20) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %22 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %23 = "llvm.insertelement"(%21, %16, %22) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %24 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %25 = "llvm.insertelement"(%23, %1, %24) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %26 = "llvm.mlir.constant"() <{value = dense<[-2.000000e+00, -2.000000e+00, 2.000000e+00, 2.000000e+00]> : vector<4xf32>}> : () -> vector<4xf32>
    %27 = "llvm.intr.fabs"(%0) <{fastmathFlags = #llvm.fastmath<none>}> : (f32) -> f32
    %28 = "llvm.intr.fabs"(%1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32) -> f32
    %29 = "llvm.intr.fabs"(%2) <{fastmathFlags = #llvm.fastmath<none>}> : (f32) -> f32
    %30 = "llvm.intr.fabs"(%13) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<4xf32>) -> vector<4xf32>
    %31 = "llvm.intr.copysign"(%14, %15) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %32 = "llvm.intr.copysign"(%14, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %33 = "llvm.intr.copysign"(%2, %15) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %34 = "llvm.intr.copysign"(%14, %2) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %35 = "llvm.intr.copysign"(%25, %26) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<4xf32>, vector<4xf32>) -> vector<4xf32>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()