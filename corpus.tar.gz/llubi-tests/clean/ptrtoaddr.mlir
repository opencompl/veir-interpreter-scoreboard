"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 4294967301 : i64}> : () -> i64
    %1 = "llvm.mlir.constant"() <{value = dense<[4294967301, 4294967303]> : vector<2xi64>}> : () -> vector<2xi64>
    %2 = "llvm.inttoptr"(%0) : (i64) -> !llvm.ptr<1>
    %3 = "llvm.ptrtoint"(%2) : (!llvm.ptr<1>) -> i64
    %4 = "llvm.ptrtoaddr"(%2) : (!llvm.ptr<1>) -> i32
    %5 = "llvm.inttoptr"(%1) : (vector<2xi64>) -> vector<2x!llvm.ptr<1>>
    %6 = "llvm.ptrtoint"(%5) : (vector<2x!llvm.ptr<1>>) -> vector<2xi64>
    %7 = "llvm.ptrtoaddr"(%5) : (vector<2x!llvm.ptr<1>>) -> vector<2xi32>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, !llvm.ptr<1> = dense<[64, 64, 64, 32]> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()