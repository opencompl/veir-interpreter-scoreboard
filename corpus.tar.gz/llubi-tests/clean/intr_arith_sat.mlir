"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.poison"() : () -> i32
    %1 = "llvm.mlir.constant"() <{value = 20 : i32}> : () -> i32
    %2 = "llvm.mlir.constant"() <{value = 10 : i32}> : () -> i32
    %3 = "llvm.mlir.constant"() <{value = -2147483647 : i32}> : () -> i32
    %4 = "llvm.mlir.constant"() <{value = -20 : i32}> : () -> i32
    %5 = "llvm.mlir.constant"() <{value = -1 : i32}> : () -> i32
    %6 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %7 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %8 = "llvm.insertelement"(%6, %5, %7) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %9 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %10 = "llvm.insertelement"(%8, %0, %9) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %11 = "llvm.mlir.constant"() <{value = dense<[2, 3]> : vector<2xi32>}> : () -> vector<2xi32>
    %12 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %13 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %14 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %15 = "llvm.insertelement"(%13, %12, %14) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %16 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %17 = "llvm.insertelement"(%15, %0, %16) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %18 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %19 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %20 = "llvm.mlir.constant"() <{value = 31 : i32}> : () -> i32
    %21 = "llvm.mlir.constant"() <{value = 32 : i32}> : () -> i32
    %22 = "llvm.mlir.constant"() <{value = dense<10> : vector<2xi32>}> : () -> vector<2xi32>
    %23 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %24 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %25 = "llvm.insertelement"(%23, %19, %24) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %26 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %27 = "llvm.insertelement"(%25, %0, %26) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %28 = "llvm.intr.sadd.sat"(%0, %1) : (i32, i32) -> i32
    %29 = "llvm.intr.sadd.sat"(%2, %1) : (i32, i32) -> i32
    %30 = "llvm.intr.sadd.sat"(%3, %4) : (i32, i32) -> i32
    %31 = "llvm.intr.sadd.sat"(%10, %11) : (vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    %32 = "llvm.intr.uadd.sat"(%2, %0) : (i32, i32) -> i32
    %33 = "llvm.intr.uadd.sat"(%2, %1) : (i32, i32) -> i32
    %34 = "llvm.intr.uadd.sat"(%5, %1) : (i32, i32) -> i32
    %35 = "llvm.intr.uadd.sat"(%17, %11) : (vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    %36 = "llvm.intr.ssub.sat"(%0, %1) : (i32, i32) -> i32
    %37 = "llvm.intr.ssub.sat"(%2, %1) : (i32, i32) -> i32
    %38 = "llvm.intr.ssub.sat"(%3, %1) : (i32, i32) -> i32
    %39 = "llvm.intr.ssub.sat"(%10, %11) : (vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    %40 = "llvm.intr.usub.sat"(%1, %0) : (i32, i32) -> i32
    %41 = "llvm.intr.usub.sat"(%1, %2) : (i32, i32) -> i32
    %42 = "llvm.intr.usub.sat"(%18, %1) : (i32, i32) -> i32
    %43 = "llvm.intr.usub.sat"(%17, %11) : (vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    %44 = "llvm.intr.sshl.sat"(%0, %19) : (i32, i32) -> i32
    %45 = "llvm.intr.sshl.sat"(%2, %19) : (i32, i32) -> i32
    %46 = "llvm.intr.sshl.sat"(%2, %20) : (i32, i32) -> i32
    %47 = "llvm.intr.sshl.sat"(%2, %21) : (i32, i32) -> i32
    %48 = "llvm.intr.sshl.sat"(%22, %27) : (vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    %49 = "llvm.intr.ushl.sat"(%2, %0) : (i32, i32) -> i32
    %50 = "llvm.intr.ushl.sat"(%2, %19) : (i32, i32) -> i32
    %51 = "llvm.intr.ushl.sat"(%2, %20) : (i32, i32) -> i32
    %52 = "llvm.intr.ushl.sat"(%2, %21) : (i32, i32) -> i32
    %53 = "llvm.intr.ushl.sat"(%22, %27) : (vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()