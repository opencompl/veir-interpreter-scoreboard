"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 2.000000e+00 : f32}> : () -> f32
    %1 = "llvm.mlir.constant"() <{value = 3.500000e+00 : f64}> : () -> f64
    %2 = "llvm.mlir.constant"() <{value = -2 : i32}> : () -> i32
    %3 = "llvm.mlir.constant"() <{value = 255 : i32}> : () -> i32
    %4 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %5 = "llvm.mlir.constant"() <{value = dense<0> : vector<4xi32>}> : () -> vector<4xi32>
    %6 = "llvm.mlir.constant"() <{value = -100000 : i32}> : () -> i32
    %7 = "llvm.mlir.constant"() <{value = 100000 : i32}> : () -> i32
    %8 = "llvm.mlir.constant"() <{value = dense<-100000> : vector<4xi32>}> : () -> vector<4xi32>
    %9 = "llvm.mlir.constant"() <{value = dense<100000> : vector<4xi32>}> : () -> vector<4xi32>
    %10 = "llvm.mlir.constant"() <{value = -255 : i32}> : () -> i32
    %11 = "llvm.mlir.constant"() <{value = -4.750000e+00 : f64}> : () -> f64
    %12 = "llvm.mlir.constant"() <{value = 4.750000e+00 : f64}> : () -> f64
    %13 = "llvm.mlir.constant"() <{value = -1.000000e+00 : f32}> : () -> f32
    %14 = "llvm.mlir.constant"() <{value = 0x7FC00000 : f32}> : () -> f32
    %15 = "llvm.fpext"(%0) <{fastmathFlags = #llvm.fastmath<none>}> : (f32) -> f64
    %16 = "llvm.fptrunc"(%1) <{fastmathFlags = #llvm.fastmath<none>}> : (f64) -> f32
    %17 = "llvm.sitofp"(%2) : (i32) -> f32
    %18 = "llvm.uitofp"(%3) : (i32) -> f32
    %19 = "llvm.sitofp"(%4) : (i32) -> f32
    %20 = "llvm.uitofp"(%4) : (i32) -> f32
    %21 = "llvm.sitofp"(%4) : (i32) -> f32
    %22 = "llvm.sitofp"(%4) : (i32) -> f32
    %23 = "llvm.uitofp"(%4) : (i32) -> f32
    %24 = "llvm.uitofp"(%4) : (i32) -> f32
    %25 = "llvm.sitofp"(%5) : (vector<4xi32>) -> vector<4xf32>
    %26 = "llvm.uitofp"(%5) : (vector<4xi32>) -> vector<4xf32>
    %27 = "llvm.sitofp"(%6) : (i32) -> f16
    %28 = "llvm.uitofp"(%7) : (i32) -> f16
    %29 = "llvm.sitofp"(%8) : (vector<4xi32>) -> vector<4xf16>
    %30 = "llvm.uitofp"(%9) : (vector<4xi32>) -> vector<4xf16>
    %31 = "llvm.sitofp"(%6) : (i32) -> f32
    %32 = "llvm.uitofp"(%7) : (i32) -> f32
    %33 = "llvm.sitofp"(%8) : (vector<4xi32>) -> vector<4xf32>
    %34 = "llvm.uitofp"(%9) : (vector<4xi32>) -> vector<4xf32>
    %35 = "llvm.uitofp"(%3) <{nonNeg}> : (i32) -> f32
    %36 = "llvm.uitofp"(%10) <{nonNeg}> : (i32) -> f32
    %37 = "llvm.fptosi"(%11) : (f64) -> i32
    %38 = "llvm.fptoui"(%12) : (f64) -> i32
    %39 = "llvm.fptoui"(%13) : (f32) -> i32
    %40 = "llvm.fptosi"(%14) : (f32) -> i32
    %41 = "llvm.sitofp"(%6) : (i32) -> f16
    %42 = "llvm.uitofp"(%7) : (i32) -> f16
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()