"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.poison"() : () -> i32
    %1 = "llvm.mlir.constant"() <{value = 20 : i32}> : () -> i32
    %2 = "llvm.mlir.constant"() <{value = 10 : i32}> : () -> i32
    %3 = "llvm.mlir.constant"() <{value = -2147483647 : i32}> : () -> i32
    %4 = "llvm.mlir.constant"() <{value = -20 : i32}> : () -> i32
    %5 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %6 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %7 = "llvm.insertelement"(%5, %2, %6) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %8 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %9 = "llvm.insertelement"(%7, %0, %8) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %10 = "llvm.mlir.constant"() <{value = dense<[20, 1]> : vector<2xi32>}> : () -> vector<2xi32>
    %11 = "llvm.mlir.constant"() <{value = -1 : i32}> : () -> i32
    %12 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %13 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %14 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %15 = "llvm.insertelement"(%13, %1, %14) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %16 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %17 = "llvm.insertelement"(%15, %0, %16) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %18 = "llvm.mlir.constant"() <{value = dense<[10, 1]> : vector<2xi32>}> : () -> vector<2xi32>
    %19 = "llvm.mlir.constant"() <{value = -4000000 : i32}> : () -> i32
    %20 = "llvm.mlir.constant"() <{value = 4000000 : i32}> : () -> i32
    %21 = "llvm.intr.sadd.with.overflow"(%0, %1) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %22 = "llvm.intr.sadd.with.overflow"(%2, %1) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %23 = "llvm.intr.sadd.with.overflow"(%3, %4) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %24 = "llvm.intr.sadd.with.overflow"(%9, %10) : (vector<2xi32>, vector<2xi32>) -> !llvm.struct<(vector<2xi32>, vector<2xi1>)>
    %25 = "llvm.intr.uadd.with.overflow"(%2, %0) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %26 = "llvm.intr.uadd.with.overflow"(%2, %1) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %27 = "llvm.intr.uadd.with.overflow"(%11, %1) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %28 = "llvm.intr.uadd.with.overflow"(%9, %10) : (vector<2xi32>, vector<2xi32>) -> !llvm.struct<(vector<2xi32>, vector<2xi1>)>
    %29 = "llvm.intr.ssub.with.overflow"(%0, %1) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %30 = "llvm.intr.ssub.with.overflow"(%2, %1) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %31 = "llvm.intr.ssub.with.overflow"(%3, %1) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %32 = "llvm.intr.ssub.with.overflow"(%9, %10) : (vector<2xi32>, vector<2xi32>) -> !llvm.struct<(vector<2xi32>, vector<2xi1>)>
    %33 = "llvm.intr.usub.with.overflow"(%1, %0) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %34 = "llvm.intr.usub.with.overflow"(%1, %2) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %35 = "llvm.intr.usub.with.overflow"(%12, %1) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %36 = "llvm.intr.usub.with.overflow"(%17, %18) : (vector<2xi32>, vector<2xi32>) -> !llvm.struct<(vector<2xi32>, vector<2xi1>)>
    %37 = "llvm.intr.smul.with.overflow"(%0, %1) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %38 = "llvm.intr.smul.with.overflow"(%2, %1) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %39 = "llvm.intr.smul.with.overflow"(%19, %20) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %40 = "llvm.intr.smul.with.overflow"(%9, %10) : (vector<2xi32>, vector<2xi32>) -> !llvm.struct<(vector<2xi32>, vector<2xi1>)>
    %41 = "llvm.intr.umul.with.overflow"(%1, %0) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %42 = "llvm.intr.umul.with.overflow"(%1, %2) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %43 = "llvm.intr.umul.with.overflow"(%20, %20) : (i32, i32) -> !llvm.struct<(i32, i1)>
    %44 = "llvm.intr.umul.with.overflow"(%17, %18) : (vector<2xi32>, vector<2xi32>) -> !llvm.struct<(vector<2xi32>, vector<2xi1>)>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()