"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.poison"() : () -> !llvm.struct<(i32, i32)>
    %1 = "llvm.mlir.constant"() <{value = 42 : i32}> : () -> i32
    %2 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %3 = "llvm.mlir.zero"() : () -> !llvm.struct<(i32, i32)>
    %4 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %5 = "llvm.mlir.poison"() : () -> !llvm.struct<(i32, struct<(struct<(i32, i32)>)>)>
    %6 = "llvm.insertvalue"(%0, %1) <{position = array<i64: 0>}> : (!llvm.struct<(i32, i32)>, i32) -> !llvm.struct<(i32, i32)>
    %7 = "llvm.extractvalue"(%6) <{position = array<i64: 0>}> : (!llvm.struct<(i32, i32)>) -> i32
    %8 = "llvm.insertvalue"(%3, %4) <{position = array<i64: 1>}> : (!llvm.struct<(i32, i32)>, i32) -> !llvm.struct<(i32, i32)>
    %9 = "llvm.insertvalue"(%5, %3) <{position = array<i64: 1, 0>}> : (!llvm.struct<(i32, struct<(struct<(i32, i32)>)>)>, !llvm.struct<(i32, i32)>) -> !llvm.struct<(i32, struct<(struct<(i32, i32)>)>)>
    %10 = "llvm.extractvalue"(%9) <{position = array<i64: 1, 0, 1>}> : (!llvm.struct<(i32, struct<(struct<(i32, i32)>)>)>) -> i32
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()