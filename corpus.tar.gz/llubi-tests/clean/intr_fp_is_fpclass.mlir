"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 0x7F800042 : f32}> : () -> f32
    %1 = "llvm.mlir.constant"() <{value = 0x7FC00042 : f32}> : () -> f32
    %2 = "llvm.mlir.constant"() <{value = 0xFFC00042 : f32}> : () -> f32
    %3 = "llvm.mlir.constant"() <{value = 0xFF800000 : f32}> : () -> f32
    %4 = "llvm.mlir.constant"() <{value = -1.000000e+00 : f32}> : () -> f32
    %5 = "llvm.mlir.constant"() <{value = -1.434930e-42 : f32}> : () -> f32
    %6 = "llvm.mlir.constant"() <{value = -0.000000e+00 : f32}> : () -> f32
    %7 = "llvm.mlir.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %8 = "llvm.mlir.constant"() <{value = 1.434930e-42 : f32}> : () -> f32
    %9 = "llvm.mlir.constant"() <{value = 1.000000e+00 : f32}> : () -> f32
    %10 = "llvm.mlir.constant"() <{value = 0x7F800000 : f32}> : () -> f32
    %11 = "llvm.mlir.poison"() : () -> f32
    %12 = "llvm.mlir.undef"() : () -> vector<4xf32>
    %13 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %14 = "llvm.insertelement"(%12, %0, %13) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %15 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %16 = "llvm.insertelement"(%14, %11, %15) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %17 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %18 = "llvm.insertelement"(%16, %9, %17) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %19 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %20 = "llvm.insertelement"(%18, %6, %19) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %21 = "llvm.intr.is.fpclass"(%0) <{bit = 1 : i32}> : (f32) -> i1
    %22 = "llvm.intr.is.fpclass"(%1) <{bit = 2 : i32}> : (f32) -> i1
    %23 = "llvm.intr.is.fpclass"(%2) <{bit = 3 : i32}> : (f32) -> i1
    %24 = "llvm.intr.is.fpclass"(%3) <{bit = 4 : i32}> : (f32) -> i1
    %25 = "llvm.intr.is.fpclass"(%4) <{bit = 8 : i32}> : (f32) -> i1
    %26 = "llvm.intr.is.fpclass"(%5) <{bit = 16 : i32}> : (f32) -> i1
    %27 = "llvm.intr.is.fpclass"(%6) <{bit = 32 : i32}> : (f32) -> i1
    %28 = "llvm.intr.is.fpclass"(%7) <{bit = 64 : i32}> : (f32) -> i1
    %29 = "llvm.intr.is.fpclass"(%8) <{bit = 128 : i32}> : (f32) -> i1
    %30 = "llvm.intr.is.fpclass"(%9) <{bit = 256 : i32}> : (f32) -> i1
    %31 = "llvm.intr.is.fpclass"(%10) <{bit = 512 : i32}> : (f32) -> i1
    %32 = "llvm.intr.is.fpclass"(%11) <{bit = 256 : i32}> : (f32) -> i1
    %33 = "llvm.intr.is.fpclass"(%20) <{bit = 291 : i32}> : (vector<4xf32>) -> vector<4xi1>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()