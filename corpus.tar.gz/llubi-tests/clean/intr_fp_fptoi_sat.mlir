"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1.277500e+02 : f32}> : () -> f32
    %1 = "llvm.mlir.constant"() <{value = -1.287500e+02 : f32}> : () -> f32
    %2 = "llvm.mlir.constant"() <{value = 1.000000e+10 : f32}> : () -> f32
    %3 = "llvm.mlir.constant"() <{value = -1.000000e+10 : f32}> : () -> f32
    %4 = "llvm.mlir.poison"() : () -> f32
    %5 = "llvm.mlir.constant"() <{value = 1.250000e+00 : f32}> : () -> f32
    %6 = "llvm.mlir.undef"() : () -> vector<4xf32>
    %7 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %8 = "llvm.insertelement"(%6, %5, %7) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %9 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %10 = "llvm.insertelement"(%8, %4, %9) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %11 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %12 = "llvm.insertelement"(%10, %2, %11) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %13 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %14 = "llvm.insertelement"(%12, %3, %13) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %15 = "llvm.mlir.constant"() <{value = 0x7FC00042 : f32}> : () -> f32
    %16 = "llvm.mlir.constant"() <{value = 0x7F800042 : f32}> : () -> f32
    %17 = "llvm.mlir.constant"() <{value = 2.557500e+02 : f32}> : () -> f32
    %18 = "llvm.mlir.constant"() <{value = -1.250000e+00 : f32}> : () -> f32
    %19 = "llvm.mlir.undef"() : () -> vector<4xf32>
    %20 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %21 = "llvm.insertelement"(%19, %5, %20) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %22 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %23 = "llvm.insertelement"(%21, %4, %22) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %24 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %25 = "llvm.insertelement"(%23, %2, %24) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %26 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %27 = "llvm.insertelement"(%25, %18, %26) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %28 = "llvm.call_intrinsic"(%0) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptosi.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %29 = "llvm.call_intrinsic"(%1) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptosi.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %30 = "llvm.call_intrinsic"(%2) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptosi.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %31 = "llvm.call_intrinsic"(%3) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptosi.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %32 = "llvm.call_intrinsic"(%4) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptosi.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %33 = "llvm.call_intrinsic"(%14) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptosi.sat.v4i8.v4f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (vector<4xf32>) -> vector<4xi8>
    %34 = "llvm.call_intrinsic"(%15) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptosi.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %35 = "llvm.call_intrinsic"(%16) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptosi.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %36 = "llvm.call_intrinsic"(%17) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptoui.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %37 = "llvm.call_intrinsic"(%18) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptoui.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %38 = "llvm.call_intrinsic"(%2) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptoui.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %39 = "llvm.call_intrinsic"(%4) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptoui.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %40 = "llvm.call_intrinsic"(%27) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptoui.sat.v4i8.v4f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (vector<4xf32>) -> vector<4xi8>
    %41 = "llvm.call_intrinsic"(%15) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptoui.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    %42 = "llvm.call_intrinsic"(%16) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.fptoui.sat.i8.f32", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 1, 0>}> : (f32) -> i8
    "llvm.return"() : () -> ()
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<i8 (f32)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nocreateundeforpoison", "nofree", "nosync", "speculatable"], sym_name = "llvm.fptosi.sat.i8.f32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<vector<4xi8> (vector<4xf32>)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nocreateundeforpoison", "nofree", "nosync", "speculatable"], sym_name = "llvm.fptosi.sat.v4i8.v4f32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<i8 (f32)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nocreateundeforpoison", "nofree", "nosync", "speculatable"], sym_name = "llvm.fptoui.sat.i8.f32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<vector<4xi8> (vector<4xf32>)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nocreateundeforpoison", "nofree", "nosync", "speculatable"], sym_name = "llvm.fptoui.sat.v4i8.v4f32", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()