"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 2.000000e+00 : f32}> : () -> f32
    %1 = "llvm.mlir.constant"() <{value = 3.000000e+00 : f32}> : () -> f32
    %2 = "llvm.mlir.constant"() <{value = 4.000000e+00 : f32}> : () -> f32
    %3 = "llvm.mlir.poison"() : () -> f32
    %4 = "llvm.mlir.undef"() : () -> vector<4xf32>
    %5 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %6 = "llvm.insertelement"(%4, %0, %5) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %7 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %8 = "llvm.insertelement"(%6, %3, %7) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %9 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %10 = "llvm.insertelement"(%8, %0, %9) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %11 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %12 = "llvm.insertelement"(%10, %0, %11) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %13 = "llvm.mlir.constant"() <{value = dense<[3.000000e+00, 3.000000e+00, 5.000000e+00, 3.000000e+00]> : vector<4xf32>}> : () -> vector<4xf32>
    %14 = "llvm.mlir.constant"() <{value = 7.000000e+00 : f32}> : () -> f32
    %15 = "llvm.mlir.undef"() : () -> vector<4xf32>
    %16 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %17 = "llvm.insertelement"(%15, %2, %16) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %18 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %19 = "llvm.insertelement"(%17, %2, %18) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %20 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %21 = "llvm.insertelement"(%19, %14, %20) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %22 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %23 = "llvm.insertelement"(%21, %3, %22) : (vector<4xf32>, f32, i32) -> vector<4xf32>
    %24 = "llvm.intr.fma"(%0, %1, %2) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32, f32) -> f32
    %25 = "llvm.intr.fma"(%3, %1, %2) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32, f32) -> f32
    %26 = "llvm.intr.fma"(%0, %3, %2) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32, f32) -> f32
    %27 = "llvm.intr.fma"(%0, %1, %3) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32, f32) -> f32
    %28 = "llvm.intr.fma"(%12, %13, %23) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<4xf32>, vector<4xf32>, vector<4xf32>) -> vector<4xf32>
    %29 = "llvm.intr.fmuladd"(%0, %1, %2) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32, f32) -> f32
    %30 = "llvm.intr.fmuladd"(%3, %1, %2) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32, f32) -> f32
    %31 = "llvm.intr.fmuladd"(%0, %3, %2) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32, f32) -> f32
    %32 = "llvm.intr.fmuladd"(%0, %1, %3) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32, f32) -> f32
    %33 = "llvm.intr.fmuladd"(%12, %13, %23) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<4xf32>, vector<4xf32>, vector<4xf32>) -> vector<4xf32>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()