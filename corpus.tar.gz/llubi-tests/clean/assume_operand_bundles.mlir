"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void (ptr, i32)>, linkage = #llvm.linkage<external>, sym_name = "assume_align_dynamic", visibility_ = 0 : i64}> ({
  ^bb0(%arg0: !llvm.ptr, %arg1: i32):
    %8 = "llvm.mlir.constant"() <{value = true}> : () -> i1
    %9 = "llvm.mlir.constant"() <{value = 4 : i32}> : () -> i32
    %10 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    "llvm.intr.assume"(%8, %arg0, %9) <{op_bundle_sizes = array<i32: 2>, op_bundle_tags = ["align"]}> : (i1, !llvm.ptr, i32) -> ()
    "llvm.intr.assume"(%8, %arg0, %arg1) <{op_bundle_sizes = array<i32: 2>, op_bundle_tags = ["align"]}> : (i1, !llvm.ptr, i32) -> ()
    "llvm.intr.assume"(%8, %arg0, %arg1, %10) <{op_bundle_sizes = array<i32: 3>, op_bundle_tags = ["align"]}> : (i1, !llvm.ptr, i32, i32) -> ()
    "llvm.return"() : () -> ()
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %1 = "llvm.mlir.constant"() <{value = true}> : () -> i1
    %2 = "llvm.mlir.constant"() <{value = 8 : i32}> : () -> i32
    %3 = "llvm.mlir.zero"() : () -> !llvm.ptr
    %4 = "llvm.mlir.constant"() <{value = 17 : i32}> : () -> i32
    %5 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %6 = "llvm.mlir.constant"() <{value = 4 : i32}> : () -> i32
    %7 = "llvm.alloca"(%0) <{alignment = 4 : i64, elem_type = i32}> : (i32) -> !llvm.ptr
    "llvm.intr.assume"(%1, %7) <{op_bundle_sizes = array<i32: 1>, op_bundle_tags = ["nonnull"]}> : (i1, !llvm.ptr) -> ()
    "llvm.intr.assume"(%1, %7) <{op_bundle_sizes = array<i32: 0, 1, 0>, op_bundle_tags = ["cold", "nonnull", "cold"]}> : (i1, !llvm.ptr) -> ()
    "llvm.call"(%7, %2) <{CConv = #llvm.cconv<ccc>, TailCallKind = #llvm.tailcallkind<none>, callee = @assume_align_dynamic, fastmathFlags = #llvm.fastmath<none>, op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (!llvm.ptr, i32) -> ()
    "llvm.intr.assume"(%1, %3, %4) <{op_bundle_sizes = array<i32: 2>, op_bundle_tags = ["align"]}> : (i1, !llvm.ptr, i32) -> ()
    "llvm.intr.assume"(%1, %3, %5) <{op_bundle_sizes = array<i32: 2>, op_bundle_tags = ["align"]}> : (i1, !llvm.ptr, i32) -> ()
    "llvm.intr.assume"(%1, %7, %6) <{op_bundle_sizes = array<i32: 2>, op_bundle_tags = ["dereferenceable"]}> : (i1, !llvm.ptr, i32) -> ()
    "llvm.intr.assume"(%1, %7, %5) <{op_bundle_sizes = array<i32: 2>, op_bundle_tags = ["dereferenceable"]}> : (i1, !llvm.ptr, i32) -> ()
    "llvm.intr.assume"(%1, %7, %6) <{op_bundle_sizes = array<i32: 2>, op_bundle_tags = ["dereferenceable_or_null"]}> : (i1, !llvm.ptr, i32) -> ()
    "llvm.intr.assume"(%1, %3, %6) <{op_bundle_sizes = array<i32: 2>, op_bundle_tags = ["dereferenceable_or_null"]}> : (i1, !llvm.ptr, i32) -> ()
    "llvm.intr.assume"(%1, %7, %6, %7, %6, %3, %6) <{op_bundle_sizes = array<i32: 2, 2, 2>, op_bundle_tags = ["dereferenceable", "dereferenceable_or_null", "dereferenceable_or_null"]}> : (i1, !llvm.ptr, i32, !llvm.ptr, i32, !llvm.ptr, i32) -> ()
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()