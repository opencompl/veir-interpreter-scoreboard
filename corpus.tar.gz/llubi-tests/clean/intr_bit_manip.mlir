"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.poison"() : () -> i32
    %1 = "llvm.mlir.constant"() <{value = 42 : i32}> : () -> i32
    %2 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %3 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %4 = "llvm.insertelement"(%2, %1, %3) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %5 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %6 = "llvm.insertelement"(%4, %0, %5) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %7 = "llvm.mlir.constant"() <{value = 12345678 : i32}> : () -> i32
    %8 = "llvm.mlir.constant"() <{value = 4200 : i32}> : () -> i32
    %9 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %10 = "llvm.mlir.poison"() : () -> i8
    %11 = "llvm.mlir.constant"() <{value = 0 : i8}> : () -> i8
    %12 = "llvm.mlir.constant"() <{value = 15 : i8}> : () -> i8
    %13 = "llvm.mlir.constant"() <{value = -1 : i8}> : () -> i8
    %14 = "llvm.mlir.constant"() <{value = 11 : i8}> : () -> i8
    %15 = "llvm.mlir.constant"() <{value = 8 : i8}> : () -> i8
    %16 = "llvm.mlir.undef"() : () -> vector<2xi8>
    %17 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %18 = "llvm.insertelement"(%16, %10, %17) : (vector<2xi8>, i8, i32) -> vector<2xi8>
    %19 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %20 = "llvm.insertelement"(%18, %12, %19) : (vector<2xi8>, i8, i32) -> vector<2xi8>
    %21 = "llvm.mlir.constant"() <{value = dense<[0, 15]> : vector<2xi8>}> : () -> vector<2xi8>
    %22 = "llvm.mlir.constant"() <{value = dense<[15, 11]> : vector<2xi8>}> : () -> vector<2xi8>
    %23 = "llvm.mlir.constant"() <{value = dense<[-1, 0]> : vector<2xi8>}> : () -> vector<2xi8>
    %24 = "llvm.mlir.constant"() <{value = dense<0> : vector<2xi8>}> : () -> vector<2xi8>
    %25 = "llvm.mlir.constant"() <{value = 2 : i8}> : () -> i8
    %26 = "llvm.mlir.constant"() <{value = 1 : i8}> : () -> i8
    %27 = "llvm.mlir.constant"() <{value = 5 : i8}> : () -> i8
    %28 = "llvm.mlir.constant"() <{value = 6 : i8}> : () -> i8
    %29 = "llvm.mlir.constant"() <{value = -4 : i8}> : () -> i8
    %30 = "llvm.mlir.constant"() <{value = -5 : i8}> : () -> i8
    %31 = "llvm.mlir.undef"() : () -> vector<2xi8>
    %32 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %33 = "llvm.insertelement"(%31, %26, %32) : (vector<2xi8>, i8, i32) -> vector<2xi8>
    %34 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %35 = "llvm.insertelement"(%33, %10, %34) : (vector<2xi8>, i8, i32) -> vector<2xi8>
    %36 = "llvm.mlir.constant"() <{value = dense<[2, 3]> : vector<2xi8>}> : () -> vector<2xi8>
    %37 = "llvm.intr.bitreverse"(%0) : (i32) -> i32
    %38 = "llvm.intr.bitreverse"(%1) : (i32) -> i32
    %39 = "llvm.intr.bitreverse"(%6) : (vector<2xi32>) -> vector<2xi32>
    %40 = "llvm.intr.bswap"(%0) : (i32) -> i32
    %41 = "llvm.intr.bswap"(%7) : (i32) -> i32
    %42 = "llvm.intr.ctpop"(%0) : (i32) -> i32
    %43 = "llvm.intr.ctpop"(%1) : (i32) -> i32
    %44 = "llvm.intr.ctlz"(%0) <{is_zero_poison = false}> : (i32) -> i32
    %45 = "llvm.intr.ctlz"(%8) <{is_zero_poison = false}> : (i32) -> i32
    %46 = "llvm.intr.ctlz"(%9) <{is_zero_poison = true}> : (i32) -> i32
    %47 = "llvm.intr.cttz"(%0) <{is_zero_poison = false}> : (i32) -> i32
    %48 = "llvm.intr.cttz"(%8) <{is_zero_poison = false}> : (i32) -> i32
    %49 = "llvm.intr.cttz"(%9) <{is_zero_poison = true}> : (i32) -> i32
    %50 = "llvm.intr.fshl"(%10, %11, %12) : (i8, i8, i8) -> i8
    %51 = "llvm.intr.fshl"(%13, %11, %12) : (i8, i8, i8) -> i8
    %52 = "llvm.intr.fshl"(%13, %11, %12) : (i8, i8, i8) -> i8
    %53 = "llvm.intr.fshl"(%12, %12, %14) : (i8, i8, i8) -> i8
    %54 = "llvm.intr.fshl"(%11, %13, %15) : (i8, i8, i8) -> i8
    %55 = "llvm.intr.fshl"(%20, %21, %22) : (vector<2xi8>, vector<2xi8>, vector<2xi8>) -> vector<2xi8>
    %56 = "llvm.intr.fshr"(%13, %11, %10) : (i8, i8, i8) -> i8
    %57 = "llvm.intr.fshr"(%13, %11, %12) : (i8, i8, i8) -> i8
    %58 = "llvm.intr.fshr"(%13, %11, %11) : (i8, i8, i8) -> i8
    %59 = "llvm.intr.fshr"(%12, %12, %14) : (i8, i8, i8) -> i8
    %60 = "llvm.intr.fshr"(%11, %13, %15) : (i8, i8, i8) -> i8
    %61 = "llvm.intr.fshr"(%23, %21, %24) : (vector<2xi8>, vector<2xi8>, vector<2xi8>) -> vector<2xi8>
    %62 = "llvm.call_intrinsic"(%10, %25) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.clmul.i8", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (i8, i8) -> i8
    %63 = "llvm.call_intrinsic"(%26, %25) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.clmul.i8", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (i8, i8) -> i8
    %64 = "llvm.call_intrinsic"(%27, %28) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.clmul.i8", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (i8, i8) -> i8
    %65 = "llvm.call_intrinsic"(%29, %25) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.clmul.i8", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (i8, i8) -> i8
    %66 = "llvm.call_intrinsic"(%29, %30) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.clmul.i8", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (i8, i8) -> i8
    %67 = "llvm.call_intrinsic"(%35, %36) <{fastmathFlags = #llvm.fastmath<none>, intrin = "llvm.clmul.v2i8", op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 2, 0>}> : (vector<2xi8>, vector<2xi8>) -> vector<2xi8>
    "llvm.return"() : () -> ()
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<i8 (i8, i8)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nocreateundeforpoison", "nofree", "nosync", "speculatable"], sym_name = "llvm.clmul.i8", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<vector<2xi8> (vector<2xi8>, vector<2xi8>)>, linkage = #llvm.linkage<external>, memory_effects = #llvm.memory_effects<other = none, argMem = none, inaccessibleMem = none, errnoMem = none, targetMem0 = none, targetMem1 = none>, no_unwind, nocallback, passthrough = ["nocreateundeforpoison", "nofree", "nosync", "speculatable"], sym_name = "llvm.clmul.v2i8", visibility_ = 0 : i64, will_return}> ({
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()