"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %1 = "llvm.mlir.poison"() : () -> i32
    %2 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %3 = "llvm.mlir.constant"() <{value = 5033160 : i32}> : () -> i32
    %4 = "llvm.mlir.constant"() <{value = 2.000000e+00 : f32}> : () -> f32
    %5 = "llvm.mlir.constant"() <{value = 0.0499999821 : f32}> : () -> f32
    %6 = "llvm.mlir.constant"() <{value = 1.000000e+00 : f16}> : () -> f16
    %7 = "llvm.mlir.constant"() <{value = dense<[0, 1]> : vector<2xi32>}> : () -> vector<2xi32>
    %8 = "llvm.mlir.constant"() <{value = 5 : i4}> : () -> i4
    %9 = "llvm.mlir.constant"() <{value = 3 : i4}> : () -> i4
    %10 = "llvm.mlir.constant"() <{value = 2 : i4}> : () -> i4
    %11 = "llvm.mlir.constant"() <{value = 1 : i4}> : () -> i4
    %12 = "llvm.mlir.constant"() <{value = dense<[1, 2, 3, 5]> : vector<4xi4>}> : () -> vector<4xi4>
    %13 = "llvm.mlir.constant"() <{value = 1 : i64}> : () -> i64
    %14 = "llvm.mlir.constant"() <{value = -32768 : i16}> : () -> i16
    %15 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %16 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %17 = "llvm.insertelement"(%15, %1, %16) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %18 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %19 = "llvm.insertelement"(%17, %2, %18) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %20 = "llvm.mlir.poison"() : () -> i64
    %21 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %22 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %23 = "llvm.insertelement"(%21, %0, %22) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %24 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %25 = "llvm.insertelement"(%23, %1, %24) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %26 = "llvm.mlir.constant"() <{value = 3 : i16}> : () -> i16
    %27 = "llvm.mlir.constant"() <{value = 2 : i16}> : () -> i16
    %28 = "llvm.mlir.poison"() : () -> i16
    %29 = "llvm.mlir.constant"() <{value = 0 : i16}> : () -> i16
    %30 = "llvm.mlir.undef"() : () -> vector<4xi16>
    %31 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %32 = "llvm.insertelement"(%30, %29, %31) : (vector<4xi16>, i16, i32) -> vector<4xi16>
    %33 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %34 = "llvm.insertelement"(%32, %28, %33) : (vector<4xi16>, i16, i32) -> vector<4xi16>
    %35 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %36 = "llvm.insertelement"(%34, %27, %35) : (vector<4xi16>, i16, i32) -> vector<4xi16>
    %37 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %38 = "llvm.insertelement"(%36, %26, %37) : (vector<4xi16>, i16, i32) -> vector<4xi16>
    %39 = "llvm.mlir.constant"() <{value = dense<[0, 1, 2, 3]> : vector<4xi32>}> : () -> vector<4xi32>
    %40 = "llvm.mlir.constant"() <{value = -1 : i3}> : () -> i3
    %41 = "llvm.mlir.constant"() <{value = -2 : i3}> : () -> i3
    %42 = "llvm.mlir.constant"() <{value = -3 : i3}> : () -> i3
    %43 = "llvm.mlir.constant"() <{value = -4 : i3}> : () -> i3
    %44 = "llvm.mlir.constant"() <{value = 3 : i3}> : () -> i3
    %45 = "llvm.mlir.constant"() <{value = 2 : i3}> : () -> i3
    %46 = "llvm.mlir.constant"() <{value = 1 : i3}> : () -> i3
    %47 = "llvm.mlir.constant"() <{value = 0 : i3}> : () -> i3
    %48 = "llvm.mlir.constant"() <{value = dense<[0, 1, 2, 3, -4, -3, -2, -1]> : vector<8xi3>}> : () -> vector<8xi3>
    %49 = "llvm.mlir.constant"() <{value = dense<[1, 2]> : vector<2xi32>}> : () -> vector<2xi32>
    %50 = "llvm.mlir.constant"() <{value = dense<[1.000000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00]> : vector<4xf16>}> : () -> vector<4xf16>
    %51 = "llvm.bitcast"(%0) : (i32) -> i32
    %52 = "llvm.bitcast"(%1) : (i32) -> i32
    %53 = "llvm.bitcast"(%2) : (i32) -> f32
    %54 = "llvm.bitcast"(%3) : (i32) -> f32
    %55 = "llvm.bitcast"(%4) : (f32) -> f32
    %56 = "llvm.bitcast"(%5) : (f32) -> f32
    %57 = "llvm.bitcast"(%4) : (f32) -> i32
    %58 = "llvm.bitcast"(%6) : (f16) -> bf16
    %59 = "llvm.alloca"(%0) <{alignment = 4 : i64, elem_type = i32}> : (i32) -> !llvm.ptr
    %60 = "llvm.bitcast"(%59) : (!llvm.ptr) -> !llvm.ptr
    %61 = "llvm.bitcast"(%7) : (vector<2xi32>) -> i64
    %62 = "llvm.bitcast"(%12) : (vector<4xi4>) -> i16
    %63 = "llvm.bitcast"(%13) : (i64) -> vector<2xi32>
    %64 = "llvm.bitcast"(%14) : (i16) -> vector<16xi1>
    %65 = "llvm.bitcast"(%19) : (vector<2xi32>) -> i64
    %66 = "llvm.bitcast"(%20) : (i64) -> vector<2xi32>
    %67 = "llvm.bitcast"(%25) : (vector<2xi32>) -> vector<4xi16>
    %68 = "llvm.bitcast"(%38) : (vector<4xi16>) -> vector<2xi32>
    %69 = "llvm.bitcast"(%39) : (vector<4xi32>) -> vector<2xi64>
    %70 = "llvm.bitcast"(%48) : (vector<8xi3>) -> vector<3xi8>
    %71 = "llvm.bitcast"(%49) : (vector<2xi32>) -> vector<4xf16>
    %72 = "llvm.bitcast"(%50) : (vector<4xf16>) -> i64
    %73 = "llvm.bitcast"(%59) : (!llvm.ptr) -> !llvm.byte<64>
    %74 = "llvm.bitcast"(%73) : (!llvm.byte<64>) -> i64
    %75 = "llvm.bitcast"(%73) : (!llvm.byte<64>) -> !llvm.ptr
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<64> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "big">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()