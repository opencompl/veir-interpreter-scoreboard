"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.poison"() : () -> i32
    %1 = "llvm.mlir.constant"() <{value = -42 : i32}> : () -> i32
    %2 = "llvm.mlir.constant"() <{value = -2147483648 : i32}> : () -> i32
    %3 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %4 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %5 = "llvm.insertelement"(%3, %0, %4) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %6 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %7 = "llvm.insertelement"(%5, %1, %6) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %8 = "llvm.mlir.constant"() <{value = -10 : i32}> : () -> i32
    %9 = "llvm.mlir.constant"() <{value = -20 : i32}> : () -> i32
    %10 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %11 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %12 = "llvm.insertelement"(%10, %0, %11) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %13 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %14 = "llvm.insertelement"(%12, %8, %13) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %15 = "llvm.mlir.constant"() <{value = dense<-20> : vector<2xi32>}> : () -> vector<2xi32>
    %16 = "llvm.mlir.constant"() <{value = 10 : i32}> : () -> i32
    %17 = "llvm.mlir.constant"() <{value = 20 : i32}> : () -> i32
    %18 = "llvm.mlir.undef"() : () -> vector<2xi32>
    %19 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %20 = "llvm.insertelement"(%18, %16, %19) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %21 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %22 = "llvm.insertelement"(%20, %0, %21) : (vector<2xi32>, i32, i32) -> vector<2xi32>
    %23 = "llvm.mlir.constant"() <{value = dense<20> : vector<2xi32>}> : () -> vector<2xi32>
    %24 = "llvm.mlir.constant"() <{value = dense<[20, 10]> : vector<2xi32>}> : () -> vector<2xi32>
    %25 = "llvm.intr.abs"(%0) <{is_int_min_poison = false}> : (i32) -> i32
    %26 = "llvm.intr.abs"(%1) <{is_int_min_poison = false}> : (i32) -> i32
    %27 = "llvm.intr.abs"(%2) <{is_int_min_poison = true}> : (i32) -> i32
    %28 = "llvm.intr.abs"(%7) <{is_int_min_poison = false}> : (vector<2xi32>) -> vector<2xi32>
    %29 = "llvm.intr.smin"(%8, %9) : (i32, i32) -> i32
    %30 = "llvm.intr.smin"(%0, %9) : (i32, i32) -> i32
    %31 = "llvm.intr.smin"(%14, %15) : (vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    %32 = "llvm.intr.umin"(%16, %17) : (i32, i32) -> i32
    %33 = "llvm.intr.umin"(%16, %0) : (i32, i32) -> i32
    %34 = "llvm.intr.umin"(%22, %23) : (vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    %35 = "llvm.intr.smax"(%8, %9) : (i32, i32) -> i32
    %36 = "llvm.intr.smax"(%0, %9) : (i32, i32) -> i32
    %37 = "llvm.intr.smax"(%14, %15) : (vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    %38 = "llvm.intr.umax"(%16, %17) : (i32, i32) -> i32
    %39 = "llvm.intr.umax"(%16, %0) : (i32, i32) -> i32
    %40 = "llvm.intr.umax"(%22, %23) : (vector<2xi32>, vector<2xi32>) -> vector<2xi32>
    %41 = "llvm.intr.scmp"(%16, %17) : (i32, i32) -> i2
    %42 = "llvm.intr.scmp"(%8, %9) : (i32, i32) -> i2
    %43 = "llvm.intr.scmp"(%16, %16) : (i32, i32) -> i2
    %44 = "llvm.intr.scmp"(%0, %16) : (i32, i32) -> i2
    %45 = "llvm.intr.scmp"(%22, %24) : (vector<2xi32>, vector<2xi32>) -> vector<2xi2>
    %46 = "llvm.intr.ucmp"(%16, %17) : (i32, i32) -> i2
    %47 = "llvm.intr.ucmp"(%17, %16) : (i32, i32) -> i2
    %48 = "llvm.intr.ucmp"(%16, %16) : (i32, i32) -> i2
    %49 = "llvm.intr.ucmp"(%16, %0) : (i32, i32) -> i2
    %50 = "llvm.intr.ucmp"(%22, %24) : (vector<2xi32>, vector<2xi32>) -> vector<2xi2>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()