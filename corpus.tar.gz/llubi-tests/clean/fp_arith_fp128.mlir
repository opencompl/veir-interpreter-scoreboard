"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1.500000e+00 : f128}> : () -> f128
    %1 = "llvm.mlir.constant"() <{value = 2.500000e+00 : f128}> : () -> f128
    %2 = "llvm.mlir.constant"() <{value = 5.000000e+00 : f128}> : () -> f128
    %3 = "llvm.mlir.constant"() <{value = 1.000000e+00 : f128}> : () -> f128
    %4 = "llvm.mlir.constant"() <{value = 2.000000e+00 : f128}> : () -> f128
    %5 = "llvm.mlir.constant"() <{value = 3.000000e+00 : f128}> : () -> f128
    %6 = "llvm.mlir.constant"() <{value = -1.500000e+00 : f128}> : () -> f128
    %7 = "llvm.mlir.constant"() <{value = dense<[1.000000e+00, 2.000000e+00]> : vector<2xf128>}> : () -> vector<2xf128>
    %8 = "llvm.mlir.constant"() <{value = 4.000000e+00 : f128}> : () -> f128
    %9 = "llvm.mlir.constant"() <{value = dense<[3.000000e+00, 4.000000e+00]> : vector<2xf128>}> : () -> vector<2xf128>
    %10 = "llvm.mlir.poison"() : () -> f128
    %11 = "llvm.mlir.constant"() <{value = 0.000000e+00 : f128}> : () -> f128
    %12 = "llvm.fadd"(%0, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f128, f128) -> f128
    %13 = "llvm.fsub"(%2, %3) <{fastmathFlags = #llvm.fastmath<none>}> : (f128, f128) -> f128
    %14 = "llvm.fmul"(%4, %5) <{fastmathFlags = #llvm.fastmath<none>}> : (f128, f128) -> f128
    %15 = "llvm.fdiv"(%3, %4) <{fastmathFlags = #llvm.fastmath<none>}> : (f128, f128) -> f128
    %16 = "llvm.fneg"(%6) <{fastmathFlags = #llvm.fastmath<none>}> : (f128) -> f128
    %17 = "llvm.fadd"(%7, %9) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<2xf128>, vector<2xf128>) -> vector<2xf128>
    %18 = "llvm.fadd"(%3, %10) <{fastmathFlags = #llvm.fastmath<none>}> : (f128, f128) -> f128
    %19 = "llvm.fneg"(%10) <{fastmathFlags = #llvm.fastmath<none>}> : (f128) -> f128
    %20 = "llvm.fdiv"(%3, %11) <{fastmathFlags = #llvm.fastmath<none>}> : (f128, f128) -> f128
    %21 = "llvm.fdiv"(%11, %11) <{fastmathFlags = #llvm.fastmath<none>}> : (f128, f128) -> f128
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()