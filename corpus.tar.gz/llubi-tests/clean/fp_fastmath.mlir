"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %1 = "llvm.mlir.constant"() <{value = 1.000000e+00 : f32}> : () -> f32
    %2 = "llvm.mlir.constant"() <{value = 2.000000e+00 : f32}> : () -> f32
    %3 = "llvm.mlir.constant"() <{value = -0.000000e+00 : f32}> : () -> f32
    %4 = "llvm.fdiv"(%0, %0) <{fastmathFlags = #llvm.fastmath<nnan>}> : (f32, f32) -> f32
    %5 = "llvm.fdiv"(%1, %0) <{fastmathFlags = #llvm.fastmath<ninf>}> : (f32, f32) -> f32
    %6 = "llvm.fadd"(%1, %2) <{fastmathFlags = #llvm.fastmath<nnan, ninf>}> : (f32, f32) -> f32
    %7 = "llvm.fneg"(%3) <{fastmathFlags = #llvm.fastmath<nsz>}> : (f32) -> f32
    %8 = "llvm.fneg"(%3) <{fastmathFlags = #llvm.fastmath<nsz>}> : (f32) -> f32
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()