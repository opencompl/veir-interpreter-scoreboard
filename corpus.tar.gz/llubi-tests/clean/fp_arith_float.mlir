"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1.500000e+00 : f32}> : () -> f32
    %1 = "llvm.mlir.constant"() <{value = 2.500000e+00 : f32}> : () -> f32
    %2 = "llvm.mlir.constant"() <{value = 5.000000e+00 : f32}> : () -> f32
    %3 = "llvm.mlir.constant"() <{value = 1.000000e+00 : f32}> : () -> f32
    %4 = "llvm.mlir.constant"() <{value = 2.000000e+00 : f32}> : () -> f32
    %5 = "llvm.mlir.constant"() <{value = 3.000000e+00 : f32}> : () -> f32
    %6 = "llvm.mlir.constant"() <{value = -1.500000e+00 : f32}> : () -> f32
    %7 = "llvm.mlir.constant"() <{value = dense<[1.000000e+00, 2.000000e+00]> : vector<2xf32>}> : () -> vector<2xf32>
    %8 = "llvm.mlir.constant"() <{value = dense<[3.000000e+00, 4.000000e+00]> : vector<2xf32>}> : () -> vector<2xf32>
    %9 = "llvm.mlir.poison"() : () -> f32
    %10 = "llvm.mlir.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %11 = "llvm.fadd"(%0, %1) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %12 = "llvm.fsub"(%2, %3) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %13 = "llvm.fmul"(%4, %5) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %14 = "llvm.fdiv"(%3, %4) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %15 = "llvm.fneg"(%6) <{fastmathFlags = #llvm.fastmath<none>}> : (f32) -> f32
    %16 = "llvm.fadd"(%7, %8) <{fastmathFlags = #llvm.fastmath<none>}> : (vector<2xf32>, vector<2xf32>) -> vector<2xf32>
    %17 = "llvm.fadd"(%3, %9) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %18 = "llvm.fneg"(%9) <{fastmathFlags = #llvm.fastmath<none>}> : (f32) -> f32
    %19 = "llvm.fdiv"(%3, %10) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    %20 = "llvm.fdiv"(%10, %10) <{fastmathFlags = #llvm.fastmath<none>}> : (f32, f32) -> f32
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()