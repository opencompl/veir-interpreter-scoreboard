"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<ptr ()>, linkage = #llvm.linkage<external>, sym_name = "dead_stack_object", visibility_ = 0 : i64}> ({
    %74 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %75 = "llvm.alloca"(%74) <{alignment = 4 : i64, elem_type = i32}> : (i32) -> !llvm.ptr
    "llvm.return"(%75) : (!llvm.ptr) -> ()
  }) : () -> ()
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %1 = "llvm.mlir.constant"() <{value = 3 : i64}> : () -> i64
    %2 = "llvm.mlir.poison"() : () -> !llvm.ptr
    %3 = "llvm.mlir.constant"() <{value = 1 : i64}> : () -> i64
    %4 = "llvm.mlir.poison"() : () -> i64
    %5 = "llvm.mlir.constant"() <{value = 18446744073709551616 : i128}> : () -> i128
    %6 = "llvm.mlir.constant"() <{value = -1 : i8}> : () -> i8
    %7 = "llvm.mlir.constant"() <{value = -1 : i64}> : () -> i64
    %8 = "llvm.mlir.constant"() <{value = 0 : i64}> : () -> i64
    %9 = "llvm.mlir.zero"() : () -> !llvm.ptr
    %10 = "llvm.mlir.constant"() <{value = 4 : i64}> : () -> i64
    %11 = "llvm.mlir.constant"() <{value = dense<[0, 2]> : vector<2xi64>}> : () -> vector<2xi64>
    %12 = "llvm.mlir.poison"() : () -> vector<2x!llvm.ptr>
    %13 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %14 = "llvm.mlir.constant"() <{value = 5 : i64}> : () -> i64
    %15 = "llvm.mlir.constant"() <{value = -2 : i32}> : () -> i32
    %16 = "llvm.mlir.constant"() <{value = -2147483649 : i64}> : () -> i64
    %17 = "llvm.mlir.constant"() <{value = 536870911 : i32}> : () -> i32
    %18 = "llvm.mlir.constant"() <{value = 536870912 : i32}> : () -> i32
    %19 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %20 = "llvm.mlir.constant"() <{value = -4 : i64}> : () -> i64
    %21 = "llvm.mlir.constant"() <{value = -16 : i64}> : () -> i64
    %22 = "llvm.mlir.constant"() <{value = 2147483647 : i64}> : () -> i64
    %23 = "llvm.mlir.constant"() <{value = 1073741823 : i32}> : () -> i32
    %24 = "llvm.mlir.constant"() <{value = 1073741824 : i32}> : () -> i32
    %25 = "llvm.mlir.constant"() <{value = 1073741821 : i64}> : () -> i64
    %26 = "llvm.mlir.constant"() <{value = 1073741822 : i64}> : () -> i64
    %27 = "llvm.mlir.constant"() <{value = dense<0> : vector<2xi64>}> : () -> vector<2xi64>
    %28 = "llvm.alloca"(%0) <{alignment = 4 : i64, elem_type = i32}> : (i32) -> !llvm.ptr
    %29 = "llvm.alloca"(%0) <{alignment = 8 : i64, elem_type = !llvm.struct<"struct", (i64, array<2 x i32>, i64)>}> : (i32) -> !llvm.ptr
    %30 = "llvm.getelementptr"(%28, %1) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %31 = "llvm.getelementptr"(%2, %3) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %32 = "llvm.getelementptr"(%28, %4) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %33 = "llvm.getelementptr"(%28, %5) <{elem_type = i32, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i128) -> !llvm.ptr
    %34 = "llvm.getelementptr"(%28, %6) <{elem_type = i32, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i8) -> !llvm.ptr
    %35 = "llvm.inttoptr"(%7) : (i64) -> !llvm.ptr
    %36 = "llvm.getelementptr"(%35, %3) <{elem_type = i32, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %37 = "llvm.getelementptr"(%29, %8, %0) <{elem_type = !llvm.struct<"struct", (i64, array<2 x i32>, i64)>, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648, 1, -2147483648>}> : (!llvm.ptr, i64, i32) -> !llvm.ptr
    %38 = "llvm.getelementptr"(%9, %10) <{elem_type = vector<[4]xi32>, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %39 = "llvm.getelementptr"(%28, %3, %11) <{elem_type = !llvm.array<2 x i32>, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648, -2147483648>}> : (!llvm.ptr, i64, vector<2xi64>) -> vector<2x!llvm.ptr>
    %40 = "llvm.insertelement"(%12, %28, %13) : (vector<2x!llvm.ptr>, !llvm.ptr, i32) -> vector<2x!llvm.ptr>
    %41 = "llvm.shufflevector"(%40, %12) <{mask = array<i32: 0, 0>}> : (vector<2x!llvm.ptr>, vector<2x!llvm.ptr>) -> vector<2x!llvm.ptr>
    %42 = "llvm.getelementptr"(%41, %3) <{elem_type = i32, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, i64) -> vector<2x!llvm.ptr>
    %43 = "llvm.getelementptr"(%41, %11) <{elem_type = i32, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (vector<2x!llvm.ptr>, vector<2xi64>) -> vector<2x!llvm.ptr>
    %44 = "llvm.getelementptr"(%9, %8) <{elem_type = i8, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %45 = "llvm.getelementptr"(%9, %3) <{elem_type = i8, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %46 = "llvm.getelementptr"(%28, %1) <{elem_type = i8, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %47 = "llvm.getelementptr"(%28, %10) <{elem_type = i8, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %48 = "llvm.getelementptr"(%28, %7) <{elem_type = i8, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %49 = "llvm.getelementptr"(%28, %14) <{elem_type = i8, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %50 = "llvm.getelementptr"(%29, %3, %15) <{elem_type = !llvm.struct<"struct", (i64, array<2 x i32>, i64)>, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648, 1, -2147483648>}> : (!llvm.ptr, i64, i32) -> !llvm.ptr
    %51 = "llvm.call"() <{CConv = #llvm.cconv<ccc>, TailCallKind = #llvm.tailcallkind<none>, callee = @dead_stack_object, fastmathFlags = #llvm.fastmath<none>, op_bundle_sizes = array<i32>, operandSegmentSizes = array<i32: 0, 0>}> : () -> !llvm.ptr
    %52 = "llvm.getelementptr"(%51, %10) <{elem_type = i8, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %53 = "llvm.getelementptr"(%51, %14) <{elem_type = i8, noWrapFlags = 3 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %54 = "llvm.getelementptr"(%28, %7) <{elem_type = i8, noWrapFlags = 2 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %55 = "llvm.getelementptr"(%35, %16) <{elem_type = i8, noWrapFlags = 2 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %56 = "llvm.getelementptr"(%9, %17) <{elem_type = i32, noWrapFlags = 2 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i32) -> !llvm.ptr
    %57 = "llvm.getelementptr"(%9, %18) <{elem_type = i32, noWrapFlags = 2 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i32) -> !llvm.ptr
    %58 = "llvm.getelementptr"(%9, %17, %0) <{elem_type = !llvm.array<2 x i16>, noWrapFlags = 2 : i32, rawConstantIndices = array<i32: -2147483648, -2147483648>}> : (!llvm.ptr, i32, i32) -> !llvm.ptr
    %59 = "llvm.getelementptr"(%9, %17, %19) <{elem_type = !llvm.array<2 x i16>, noWrapFlags = 2 : i32, rawConstantIndices = array<i32: -2147483648, -2147483648>}> : (!llvm.ptr, i32, i32) -> !llvm.ptr
    %60 = "llvm.inttoptr"(%20) : (i64) -> !llvm.ptr
    %61 = "llvm.getelementptr"(%60, %1) <{elem_type = i8, noWrapFlags = 2 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %62 = "llvm.getelementptr"(%60, %10) <{elem_type = i8, noWrapFlags = 2 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %63 = "llvm.getelementptr"(%60, %20) <{elem_type = i8, noWrapFlags = 2 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %64 = "llvm.getelementptr"(%28, %21) <{elem_type = i8, noWrapFlags = 2 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %65 = "llvm.getelementptr"(%9, %22) <{elem_type = i8, noWrapFlags = 4 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %66 = "llvm.getelementptr"(%9, %7) <{elem_type = i8, noWrapFlags = 4 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %67 = "llvm.getelementptr"(%9, %23) <{elem_type = i32, noWrapFlags = 4 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i32) -> !llvm.ptr
    %68 = "llvm.getelementptr"(%9, %24) <{elem_type = i32, noWrapFlags = 4 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i32) -> !llvm.ptr
    %69 = "llvm.getelementptr"(%9, %23, %0) <{elem_type = !llvm.array<2 x i16>, noWrapFlags = 4 : i32, rawConstantIndices = array<i32: -2147483648, -2147483648>}> : (!llvm.ptr, i32, i32) -> !llvm.ptr
    %70 = "llvm.getelementptr"(%9, %23, %19) <{elem_type = !llvm.array<2 x i16>, noWrapFlags = 4 : i32, rawConstantIndices = array<i32: -2147483648, -2147483648>}> : (!llvm.ptr, i32, i32) -> !llvm.ptr
    %71 = "llvm.getelementptr"(%28, %25) <{elem_type = i32, noWrapFlags = 4 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %72 = "llvm.getelementptr"(%28, %26) <{elem_type = i32, noWrapFlags = 4 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, i64) -> !llvm.ptr
    %73 = "llvm.getelementptr"(%28, %27) <{elem_type = i8, noWrapFlags = 0 : i32, rawConstantIndices = array<i32: -2147483648>}> : (!llvm.ptr, vector<2xi64>) -> vector<2x!llvm.ptr>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<[64, 64, 64, 32]> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()