"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.poison"() : () -> vector<4xi32>
    %1 = "llvm.mlir.constant"() <{value = 42 : i32}> : () -> i32
    %2 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %3 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %4 = "llvm.mlir.constant"() <{value = dense<0> : vector<4xi32>}> : () -> vector<4xi32>
    %5 = "llvm.mlir.constant"() <{value = 5 : i32}> : () -> i32
    %6 = "llvm.mlir.poison"() : () -> vector<[4]xi32>
    %7 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %8 = "llvm.mlir.poison"() : () -> i32
    %9 = "llvm.mlir.undef"() : () -> vector<4xi32>
    %10 = "llvm.mlir.constant"() <{value = 0 : i32}> : () -> i32
    %11 = "llvm.insertelement"(%9, %2, %10) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %12 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %13 = "llvm.insertelement"(%11, %8, %12) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %14 = "llvm.mlir.constant"() <{value = 2 : i32}> : () -> i32
    %15 = "llvm.insertelement"(%13, %7, %14) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %16 = "llvm.mlir.constant"() <{value = 3 : i32}> : () -> i32
    %17 = "llvm.insertelement"(%15, %3, %16) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %18 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %19 = "llvm.mlir.constant"() <{value = dense<[4, 5, 6, 7]> : vector<4xi32>}> : () -> vector<4xi32>
    %20 = "llvm.mlir.constant"() <{value = dense<[0, 1, 2, 3]> : vector<4xi32>}> : () -> vector<4xi32>
    %21 = "llvm.insertelement"(%0, %1, %2) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %22 = "llvm.shufflevector"(%21, %0) <{mask = array<i32: 0, 0, 0, 0>}> : (vector<4xi32>, vector<4xi32>) -> vector<4xi32>
    %23 = "llvm.extractelement"(%22, %3) : (vector<4xi32>, i32) -> i32
    %24 = "llvm.insertelement"(%4, %1, %5) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %25 = "llvm.extractelement"(%4, %5) : (vector<4xi32>, i32) -> i32
    %26 = "llvm.insertelement"(%6, %1, %2) : (vector<[4]xi32>, i32, i32) -> vector<[4]xi32>
    %27 = "llvm.shufflevector"(%26, %6) <{mask = array<i32: 0, 0, 0, 0>}> : (vector<[4]xi32>, vector<[4]xi32>) -> vector<[4]xi32>
    %28 = "llvm.extractelement"(%27, %3) : (vector<[4]xi32>, i32) -> i32
    %29 = "llvm.insertelement"(%17, %18, %18) : (vector<4xi32>, i32, i32) -> vector<4xi32>
    %30 = "llvm.shufflevector"(%17, %19) <{mask = array<i32: 7, 1, -1, 0>}> : (vector<4xi32>, vector<4xi32>) -> vector<4xi32>
    %31 = "llvm.shufflevector"(%20, %19) <{mask = array<i32: 7, -1, 3>}> : (vector<4xi32>, vector<4xi32>) -> vector<3xi32>
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()