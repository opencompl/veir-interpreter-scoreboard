"builtin.module"() ({
  "llvm.func"() <{CConv = #llvm.cconv<ccc>, function_type = !llvm.func<void ()>, linkage = #llvm.linkage<external>, sym_name = "main", visibility_ = 0 : i64}> ({
    %0 = "llvm.mlir.constant"() <{value = 1 : i32}> : () -> i32
    %1 = "llvm.mlir.constant"() <{value = -8 : i64}> : () -> i64
    %2 = "llvm.mlir.constant"() <{value = true}> : () -> i1
    %3 = "llvm.mlir.constant"() <{value = 17 : i32}> : () -> i32
    %4 = "llvm.mlir.constant"() <{value = 8 : i32}> : () -> i32
    %5 = "llvm.mlir.constant"() <{value = -8 : i8}> : () -> i8
    %6 = "llvm.mlir.constant"() <{value = 17 : i8}> : () -> i8
    %7 = "llvm.mlir.constant"() <{value = 4 : i64}> : () -> i64
    %8 = "llvm.alloca"(%0) <{alignment = 4 : i64, elem_type = i32}> : (i32) -> !llvm.ptr
    %9 = "llvm.inttoptr"(%1) : (i64) -> !llvm.ptr
    "llvm.intr.assume"(%2, %8, %3, %4) <{op_bundle_sizes = array<i32: 3>, op_bundle_tags = ["align"]}> : (i1, !llvm.ptr, i32, i32) -> ()
    "llvm.intr.assume"(%2, %9, %3, %5) <{op_bundle_sizes = array<i32: 3>, op_bundle_tags = ["align"]}> : (i1, !llvm.ptr, i32, i8) -> ()
    "llvm.intr.assume"(%2, %8, %6, %7) <{op_bundle_sizes = array<i32: 3>, op_bundle_tags = ["align"]}> : (i1, !llvm.ptr, i8, i64) -> ()
    "llvm.return"() : () -> ()
  }) : () -> ()
}) {dlti.dl_spec = #dlti.dl_spec<!llvm.ptr = dense<64> : vector<4xi64>, i1 = dense<8> : vector<2xi64>, i8 = dense<8> : vector<2xi64>, i16 = dense<16> : vector<2xi64>, i32 = dense<32> : vector<2xi64>, i64 = dense<[32, 64]> : vector<2xi64>, f16 = dense<16> : vector<2xi64>, f64 = dense<64> : vector<2xi64>, f128 = dense<128> : vector<2xi64>, "dlti.endianness" = "little">, llvm.module_asm = [], llvm.target_triple = ""} : () -> ()